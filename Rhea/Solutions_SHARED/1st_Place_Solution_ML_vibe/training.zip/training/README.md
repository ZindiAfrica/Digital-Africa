# Soil Nutrient Prediction Pipeline
## By ML_vibe

### Dependencies Required:
- pandas
- numpy
- scikit-learn
- lightgbm
- joblib
- earthengine-api
- tqdm

### Instructions:

1. **Environment Setup:** Ensure all raw dataset files (`Train.csv`, `TestSet.csv`, `Sample_Collection_Dates.csv`, `TargetPred_To_Keep.csv`) are in the same directory as the scripts.
2. **Generate SCORPAN Features (Crucial for New/Hidden Data):** Run `python create_band_feature.py` to authenticate with Google Earth Engine and dynamically extract the environmental satellite bands and climate data for the new soil samples. This will output the `scorpan_environmental_features_v2.csv` file required for model training and inference.
3. **Train Models:** Run `python train.py` to process the training data, apply the covariate subsampling filters, and save the dual-architecture (Random Forest & LightGBM) models into the `saved_models/` directory.
4. **Run Inference:** Run `python predict.py` to load the new hidden test data, run inference using the saved models (routing Base models to pre-2025 data and Filtered models to 2025 data), apply the domain extrapolation multipliers, and generate the final `submission.csv`.