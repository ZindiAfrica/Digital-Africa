# Rhea Soil Nutrient Prediction Challenge - Final Solution Document

**Author:** ML_vibe

## 1. Overview & Methodology

The primary challenge of this dataset lies in the temporal and spatial domain shift between the historical training data and the new 2025 test cohort. A model trained naively on the historical data will overfit to past environmental baselines and fail to generalize to the 2025 samples.

To solve this, my solution relies on three core pillars:

1. **Adversarially Purified Feature Engineering:** Extracting robust satellite indices while dropping features highly sensitive to temporal shifts.
2. **Dual-Algorithm Ensembling:** Utilizing both Random Forest (for localized spatial noise) and LightGBM (for wide-scale environmental gradients).
3. **Domain Shift Calibration:** Handling the 2025 distribution shift via strict Covariate Subsampling (training data filtering) and Domain Extrapolation.

---

## 2. Feature Engineering & Selection

I utilized the provided Sentinel-2 bands and engineered a suite of domain-specific agricultural and soil indices to capture soil chemistry:

* **BSI** (Bare Soil Index)
* **SAVI** (Soil Adjusted Vegetation Index)
* **BI** (Brightness Index)
* **CI** (Color Index) & **RI** (Redness Index)
* **EVI** (Enhanced Vegetation Index) & **NDVI**

**Adversarial Feature Selection:** To prevent temporal overfitting, I conducted adversarial validation between the historical and 2025 cohorts. Features that allowed a classifier to easily separate the two time periods (e.g., highly volatile moisture indices or specific raw bands affected by atmospheric changes) were aggressively dropped. Only the "Ultra-Safe" features and exact spatial coordinates (`Latitude`, `Longitude`) were retained for the final model.

---

## 3. Handling the 2025 Domain Shift

Statistical analysis revealed that the 2025 test cohort exists in a different distributional space than the historical data. To correct this covariate shift without relying on arbitrary post-processing, I implemented a split strategy:

### Strategy A: Covariate Subsampling (Ceiling Filters)

For targets where the 2025 baseline was significantly lower than historical extremes (e.g., Calcium, Potassium, Magnesium), I applied a targeted filter to the training data.

* **Method:** Extreme high outliers were dynamically dropped from the training set *before* model fitting.
* **Result:** By restricting the training distribution to match the anticipated bounds of the 2025 region, the models naturally learned to predict within the correct, lower ranges without requiring arbitrary down-scaling.

### Strategy B: Domain Extrapolation (Floor Adjustments)

For specific targets where the 2025 regional baseline exceeded the historical data (e.g., Zinc, Nitrogen), filtering the training data was impossible as those higher values did not exist historically.

* **Method:** For these specific targets, the model was trained on the full dataset. The raw predictions were then calibrated using an Extrapolation Ratio.
* **Robust Calculation:** To ensure mathematical stability, these ratios were calculated against the **5% Trimmed Mean** of the raw predictions, protecting the scaling factors from being skewed by extreme localized outliers.

---

## 4. Model Architecture & Inference Routing

Different soil nutrients exhibit different spatial behaviors. Some are highly localized (perfect for deep, independent bagging trees), while others follow subtle gradients (perfect for sequential error-correcting boosting).

To maximize stability, I utilized a **100% Ensemble Approach**:

* **Random Forest Regressor (50 Trees):** Captures high-variance spatial localities.
* **LightGBM Regressor (200 Trees):** Captures broader geographical trends.
* Both models were trained on the unscaled, raw `mg/kg` targets, and their predictions were blended via a 50/50 weighted average.

**The Surgical Routing Pipeline:**
To ensure zero data leakage and preserve historical accuracy, the inference script routes the predictions dynamically:

1. **Pre-2025 Data:** Predicted using "Base Models" trained on 100% of the historical data to build the deepest possible spatial map.
2. **2025 Data:** Predicted using "Filtered Models" (trained strictly on the covariate-subsampled data) and calibrated with the extrapolation ratios, surgically patching only the 2025 rows in the final submission matrix.

This pipeline ensures robust, mathematically justified predictions that respect both local spatial properties and wide-scale temporal shifts.

---