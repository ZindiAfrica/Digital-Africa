# train.py
import pandas as pd
import numpy as np
import os
import joblib
from sklearn.ensemble import RandomForestRegressor
import lightgbm as lgb

# Create directory to save models
os.makedirs('saved_models', exist_ok=True)

def find_path(name):
    for root, dirs, files in os.walk(os.getcwd()):
        if name in files: return os.path.join(root, name)
    for root, dirs, files in os.walk('/kaggle/input/'):
        if name in files: return os.path.join(root, name)
    return name 

print("📂 Loading Train & SCORPAN Data...")
train = pd.read_csv(find_path('data/Train.csv'))
scorpan_df = pd.read_csv(find_path('data/scorpan_environmental_features_v2.csv'))

b2 = scorpan_df['B2']
b3 = scorpan_df['B3']
b4 = scorpan_df['B4']
b8 = scorpan_df['B8']
b11 = scorpan_df['B11']
b12 = scorpan_df['B12']

scorpan_df['FE_BSI'] = ((b11 + b4) - (b8 + b2)) / ((b11 + b4) + (b8 + b2) + 1e-6)
scorpan_df['FE_SAVI'] = ((b8 - b4) / (b8 + b4 + 0.5)) * 1.5
scorpan_df['FE_BI'] = np.sqrt(b4**2 + b3**2)
scorpan_df['FE_CI'] = (b4 - b3) / (b4 + b3 + 1e-6)
scorpan_df['FE_RI'] = b4 / (b3 + 1e-6)
scorpan_df['FE_EVI'] = 2.5 * ((b8 - b4) / (b8 + 6 * b4 - 7.5 * b2 + 1 + 1e-6))

ultra_safe_features = [
    'Latitude', 'Longitude', 
    'B12', 'B11', 'B3', 'FE_BSI', 'FE_EVI', 'FE_CI', 
    'NDVI', 'B4', 'FE_BI', 'FE_RI', 'FE_SAVI'
]

train_sc = train.merge(scorpan_df[['ID'] + ultra_safe_features[2:]], on='ID', how='left')
master_scorpan = train_sc[ultra_safe_features].drop_duplicates(subset=['Latitude', 'Longitude'])

targets_all = ['Al', 'B', 'Ca', 'Cu', 'Fe', 'K', 'Mg', 'Mn', 'N', 'Na', 'P', 'S', 'Zn']
train = train[['ID', 'Latitude', 'Longitude'] + targets_all].merge(master_scorpan, on=['Latitude', 'Longitude'], how='left')

domain_shift_ceilings = {
    'Al': 732.0, 'Ca': 731.0, 'Mg': 225.0, 'Mn': 163.0, 
    'P':  18.0,  'K':  159.0, 'Fe': 50.0,  'Cu': 4.7
}

rf_targets = ['Ca', 'Cu', 'Fe', 'K', 'Mg', 'Mn', 'P', 'Al', 'Zn']

print(f"\n🚀 Training Dual-Model Architecture & Saving to disk...")

for t in targets_all:
    train_t = train.dropna(subset=[t] + ultra_safe_features).copy()
    
    if len(train_t) > 0:
        # --- 1. TRAIN BASE MODEL (For Old Data) ---
        X_train_base = train_t[ultra_safe_features]
        y_train_base = train_t[t].clip(lower=0)
        
        if t in rf_targets:
            model_base = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
        else:
            model_base = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05, random_state=42, n_jobs=-1, verbose=-1)
            
        model_base.fit(X_train_base, y_train_base)
        joblib.dump(model_base, f'saved_models/model_base_{t}.joblib')
        
        # --- 2. TRAIN FILTERED MODEL (For 2025 Data) ---
        train_filtered = train_t.copy()
        if t in domain_shift_ceilings:
            train_filtered = train_filtered[train_filtered[t] <= domain_shift_ceilings[t]]
            
        if len(train_filtered) > 0:
            X_train_filt = train_filtered[ultra_safe_features]
            y_train_filt = train_filtered[t].clip(lower=0)
            
            if t in rf_targets:
                model_filt = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
            else:
                model_filt = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05, random_state=42, n_jobs=-1, verbose=-1)
                
            model_filt.fit(X_train_filt, y_train_filt)
            joblib.dump(model_filt, f'saved_models/model_filtered_{t}.joblib')
            print(f"   ✅ Saved Base & Filtered models for {t}")
        else:
            print(f"   ⚠️ Saved Base model only for {t} (0 rows after filter)")

print("\n🎉 Training complete! Models saved in 'saved_models/'.")