import ee
import pandas as pd
import numpy as np
import os
from tqdm.auto import tqdm

# --- 1. AUTHENTICATE & INITIALIZE EARTH ENGINE ---
# Using your specific Project ID
PROJECT_ID = 'project_id_here'  # <-- REPLACE with your actual Project ID

try:
    ee.Initialize(project=PROJECT_ID)
    print(f"🌍 Earth Engine Initialized with Project: {PROJECT_ID}")
except Exception as e:
    print("Authenticating...")
    ee.Authenticate()
    ee.Initialize(project=PROJECT_ID)
    print(f"🌍 Earth Engine Initialized with Project: {PROJECT_ID}")


    # --- 2. LOAD DATA ---
def find_path(name):
    for root, dirs, files in os.walk('/kaggle/input/'):
        if name in files: return os.path.join(root, name)
    return name

train = pd.read_csv(find_path('Train.csv'))
test = pd.read_csv(find_path('TestSet.csv'))
dates = pd.read_csv(find_path('Sample_Collection_Dates.csv'))

all_coords = pd.concat([train[['ID', 'Latitude', 'Longitude']], 
                        test[['ID', 'Latitude', 'Longitude']]])

dates['end_date'] = pd.to_datetime(dates['end_date'], dayfirst=True)
dates['Year'] = dates['end_date'].dt.year
all_coords = all_coords.merge(dates[['ID', 'Year']], on='ID', how='left')
all_coords = all_coords.dropna(subset=['Latitude', 'Longitude', 'Year'])

# --- 3. EXTRACTION FUNCTION V2 ---
def get_earth_engine_features(df_chunk, raw_year):
    features = [ee.Feature(ee.Geometry.Point([row['Longitude'], row['Latitude']]), {'ID': row['ID']}) 
                for _, row in df_chunk.iterrows()]
    fc = ee.FeatureCollection(features)
    
    # FALLBACKS:
    # 1. TerraClimate only goes up to ~2023/2024. For 2025, use 2023.
    climate_year = min(int(raw_year), 2023)
    # 2. Sentinel-2 SR Harmonized is globally complete from 2019 onward.
    sat_year = max(int(raw_year), 2019)
    
    # A. SATELLITE IMAGERY (Relaxed cloud filter to 30%)
    s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED') \
        .filterDate(f'{sat_year}-01-01', f'{sat_year}-12-31') \
        .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30)) \
        .median() \
        .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
    
    ndvi = s2.normalizedDifference(['B8', 'B4']).rename('NDVI')
    s2 = s2.addBands(ndvi)
    
    # B. CLIMATE (Using climate_year fallback)
    climate = ee.ImageCollection("IDAHO_EPSCOR/TERRACLIMATE") \
        .filterDate(f'{climate_year}-01-01', f'{climate_year}-12-31')
    precip = climate.select('pr').sum().rename('Precipitation')
    temp = climate.select('tmmx').mean().multiply(0.1).rename('Max_Temp')
    
    # C. TOPOGRAPHY
    dem = ee.Image("USGS/SRTMGL1_003").select('elevation').rename('Elevation')
    slope = ee.Terrain.slope(dem).rename('Slope')
    
    # D. STATIC SOIL MAPS
    ph = ee.Image("OpenLandMap/SOL/SOL_PH-H2O_USDA-4C1A2A_M/v02").select('b0').rename('pH_Global')
    clay = ee.Image("OpenLandMap/SOL/SOL_CLAY-WFRACTION_USDA-3A1A1A_M/v02").select('b0').rename('Clay_Global')
    sand = ee.Image("OpenLandMap/SOL/SOL_SAND-WFRACTION_USDA-3A1A1A_M/v02").select('b0').rename('Sand_Global')
    
    # Combine everything
    master_image = s2.addBands([precip, temp, dem, slope, ph, clay, sand])
    
    # tileScale=4 prevents memory timeouts!
    sampled = master_image.reduceRegions(
        collection=fc,
        reducer=ee.Reducer.first(),
        scale=30,
        tileScale=4 
    )
    
    return sampled.getInfo()['features']

# --- 4. BATCH PROCESSING WITH SMALLER CHUNKS ---
unique_years = all_coords['Year'].unique()
all_extracted_data = []

# Reduced chunk size from 1000 to 100 to fix the "5000 elements" query abort error
CHUNK_SIZE = 3000 

for y in unique_years:
    df_y = all_coords[all_coords['Year'] == y]
    print(f"\n🛰️ Processing Year: {int(y)} | Total points: {len(df_y)}")
    
    for i in tqdm(range(0, len(df_y), CHUNK_SIZE), desc=f"Chunks for {int(y)}"):
        chunk = df_y.iloc[i:i+CHUNK_SIZE]
        try:
            extracted = get_earth_engine_features(chunk, y)
            for feat in extracted:
                all_extracted_data.append(feat['properties'])
        except Exception as e:
            print(f"⚠️ Error on chunk {i}: {e}")

# --- 5. CLEANUP & SAVE ---
final_df = pd.DataFrame(all_extracted_data)

if 'system:index' in final_df.columns:
    final_df = final_df.drop(columns=['system:index'])

final_df.to_csv('scorpan_environmental_features_v2.csv', index=False)
print("\n🎉 SUCCESS! Extracted Satellite, Climate, Topography, and Soil data.")
print(final_df.head())