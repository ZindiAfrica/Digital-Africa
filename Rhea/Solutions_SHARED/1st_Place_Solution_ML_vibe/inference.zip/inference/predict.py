# predict.py
import pandas as pd
import numpy as np
import os
import joblib

def find_path(name):
    for root, dirs, files in os.walk(os.getcwd()):
        if name in files: return os.path.join(root, name)
    return name 

print("📂 Loading Hidden Test Data & Models...")
test = pd.read_csv(find_path('data/TestSet.csv')) # Zindi will replace this with hidden data
mask = pd.read_csv(find_path('data/TargetPred_To_Keep.csv'))
dates = pd.read_csv(find_path('data/Sample_Collection_Dates.csv'))

dates['end_date'] = pd.to_datetime(dates['end_date'], dayfirst=True)
dates['Year'] = dates['end_date'].dt.year
test = test.merge(dates[['ID', 'Year']], on='ID', how='left')
is_2025 = test['Year'] >= 2025

scorpan_df = pd.read_csv(find_path('data/scorpan_environmental_features_v2.csv'))

b2 = scorpan_df['B2']
b3 = scorpan_df['B3']
b4 = scorpan_df['B4']
b8 = scorpan_df['B8']
b11 = scorpan_df['B11']
b12 = scorpan_df['B12']

scorpan_df['FE_BSI'] = ((b11 + b4) - (b8 + b2)) / ((b11 + b4) + (b8 + b2) + 1e-6)
scorpan_df['FE_SAVI'] = ((b8 - b4) / (b8 + b4 + 0.5)) * 1.5
scorpan_df['FE_BI'] = np.sqrt(b4**2 + b3**2)
scorpan_df['FE_CI'] = (b4 - b3) / (b4 + b3 + 1e-6)
scorpan_df['FE_RI'] = b4 / (b3 + 1e-6)
scorpan_df['FE_EVI'] = 2.5 * ((b8 - b4) / (b8 + 6 * b4 - 7.5 * b2 + 1 + 1e-6))

ultra_safe_features = [
    'Latitude', 'Longitude', 
    'B12', 'B11', 'B3', 'FE_BSI', 'FE_EVI', 'FE_CI', 
    'NDVI', 'B4', 'FE_BI', 'FE_RI', 'FE_SAVI'
]

test_sc = test.merge(scorpan_df[['ID'] + ultra_safe_features[2:]], on='ID', how='left')
master_scorpan = test_sc[ultra_safe_features].drop_duplicates(subset=['Latitude', 'Longitude'])

targets_all = ['Al', 'B', 'Ca', 'Cu', 'Fe', 'K', 'Mg', 'Mn', 'N', 'Na', 'P', 'S', 'Zn']
test = test[['ID', 'Latitude', 'Longitude', 'Year']].merge(master_scorpan, on=['Latitude', 'Longitude'], how='left')

domain_shift_extrapolators = {
    'Zn': 2.5, 'S': 2.5, 'B': 3.0, 'N': 4.1366, 'Al': .8
}

submission = pd.DataFrame({'ID': test['ID']})
base_sub = pd.DataFrame({'ID': test['ID']})
test.set_index('ID', inplace=True)
base_sub.set_index('ID', inplace=True)

print("\n🚀 Running Dual-Model Inference & Patching...")
for t in targets_all:
    # Safely handle missing features via 0 fill
    X_test_all = test[ultra_safe_features].copy().fillna(0)
    
    # 1. PREDICT BASE (For Old Data)
    base_model_path = f'saved_models/model_base_{t}.joblib'
    if os.path.exists(base_model_path):
        model_base = joblib.load(base_model_path)
        base_sub[f'Target_{t}'] = model_base.predict(X_test_all)
    else:
        base_sub[f'Target_{t}'] = 0.0

    # 2. PREDICT FILTERED & PATCH (For 2025 Data)
    filt_model_path = f'saved_models/model_filtered_{t}.joblib'
    if os.path.exists(filt_model_path) and is_2025.any():
        model_filt = joblib.load(filt_model_path)
        X_test_2025 = X_test_all.loc[is_2025.values]
        
        preds_2025 = model_filt.predict(X_test_2025)
        
        if t in domain_shift_extrapolators:
            preds_2025 *= domain_shift_extrapolators[t]
            
        update_ids = test.loc[is_2025.values].index
        base_sub.loc[update_ids, f'Target_{t}'] = preds_2025
        print(f"   ⚡ Processed and Patched {t}")

base_sub.reset_index(inplace=True)

print("\n🛡️ Re-applying Zindi Masks for Safety...")
final_sub = mask.rename(columns={m: f'{m}_mask' for m in targets_all}).merge(base_sub, on='ID')

for m in targets_all:
    final_sub[f'Target_{m}'] = final_sub[f'Target_{m}'].fillna(0.0) * final_sub[f'{m}_mask']

save_name = 'submission.csv'
final_sub[['ID'] + [f'Target_{m}' for m in targets_all]].to_csv(save_name, index=False)
print(f"🎉 Done! '{save_name}' generated for final evaluation.")