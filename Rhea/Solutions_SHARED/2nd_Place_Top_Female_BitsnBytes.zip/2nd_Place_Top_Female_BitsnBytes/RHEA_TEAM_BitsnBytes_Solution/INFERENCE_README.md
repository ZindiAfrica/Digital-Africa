# Inference Guide

How to generate predictions on a new test set CSV.

---

## What to change

Each notebook has a clearly marked cell near the top:

```python
## LOAD THE NEW CSV FILE HERE PLEASE
TEST_PATH = "TestSet.csv"  # update the path
```

Replace `"TestSet.csv"` with the path to your new test CSV, then run the notebook top to bottom.

For the Colab notebook (Notebook 4), the equivalent variable is:

```python
TEST_CSV = "/content/TestSet.csv"  # update as necessary please
```

That is the only change needed per notebook.

---

## Notebooks and their outputs

| # | Notebook | Output CSV |
|---|----------|-----------|
| 1 | `rhea-koeppen-geiger-stratified-clustering` | `rhea_sub_village_fin.csv` |
| 2 | `w-priors-rhea-koeppen-geiger-stratified-clustering` | `rhea_sub_village_fin_v2.csv` |
| 3 | `spatial-predictions-using-ensemble-machine-learnin` | `rhea_sub_ridge.csv` |
| 4 | `NOTEBOOK_colab__Fin_Rhea_Soil_Nutrient_Prediction_Kenya_Boosted_Reg` | `submission_Fin_Rhea_Soil_Nutrient_Prediction_Kenya_Boosted_Reg.csv` |
| 5 | `apprch-frm-winning-solution-for-afsis-2014-compe` | `rhea_ensemble_submission.csv` |
| C-inf | `kg-stratified-villages-inference` | `rhea_sub_village_fin.csv` |
| 6 | `bringing-everything-together` | Final ensemble submission |

---

## KG-Stratified Villages (train/inference split)

Unlike the other notebooks which train and predict in a single run, this approach is split into two:

**Training** (`kg-stratified-villages.ipynb`) — run once to train 15-fold LightGBM models and save all artifacts. No test set needed at this stage.

**Inference** (`kg-stratified-villages-inference.ipynb`) — loads the saved models and artifacts, predicts on whatever test CSV you point it to. Change the same `TEST_PATH` variable at the top. This is the notebook to re-run when a new test set arrives.

---

## Run order

Notebooks 1-5 and C-inf can run in any order (C-inf requires the training notebook C to have been run first). Notebook 6 runs last (it reads the submission CSVs above and blends them; kindly make the submission files available therein).
