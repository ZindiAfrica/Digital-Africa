# Rhea Soil Nutrient Prediction Challenge

Predicting 13 soil nutrients (Al, B, Ca, Cu, Fe, K, Mg, Mn, N, Na, P, S, Zn) across Africa using geospatial features and machine learning, where lab-tested samples are unavailable.

---

## Data Preparation Notebooks

These notebooks extract and cache remote sensing features or train reusable models. They must run before the notebooks that depend on them.

### A. MODIS/SRTM/CHIRPS/iSDA/AfSIS + BART
**File:** `modis-srtm-chirps-is-afsis-bart.ipynb`
**Runtime:** ~50 min (TPU v5e-8, Kaggle)
**Output dataset:** `DATA_MODIS/SRTM/CHIRPS/is/AfSIS`
**Used by:** Notebook 5 (Apprch frm Winning Solution for AfSIS 2014 Compe)

Extracts and caches spatial features from five remote sensing sources in parallel: MODIS vegetation/albedo/LST via the ORNL DAAC REST API, SRTM elevation and terrain derivatives (slope, CTI, relief), CHIRPS rainfall seasonality and aridity metrics, iSDAsoil 30 m raster predictions via COG on S3, and AfSIS wet-chemistry nearest-neighbor IDW statistics. All features are pickled per source for downstream consumption.

---

### B. RHEA Spatial EML v2
**File:** `rhea-spatial-eml-v2.ipynb`
**Runtime:** ~3 hr 12 min (CPU, Kaggle)
**Output dataset:** `DATA_RHEA_spatial_eml_v2`
**Used by:** Notebook 3 (Spatial Predictions Using Ensemble Machine Learning)

Multi-source feature engineering pipeline: extracts iSDAsoil raster properties, Sentinel-2 spectral indices (NDVI, BSI, NDSI, NDMI, NDWI, SAVI, EVI) via Element84 STAC API, CHIRPS rainfall, and WorldClim bioclimatic variables. Also builds oblique coordinate projections, KNN distance features to K-means centroids, PCA components, and neighbor target-value statistics with leakage-safe CV handling. All intermediate results are cached to pickle files.

---

### C. KG-Stratified Villages (Training)
**File:** `kg-stratified-villages.ipynb`
**Runtime:** ~3x the original 5-fold runtime (CPU/GPU, Kaggle)
**Output:** `kg_village_models/` directory (195 LightGBM model files + pipeline artifacts)
**Used by:** Notebook C-inf (KG-Stratified Villages Inference)

Runs the full KG-stratified village pipeline on training data with 15-fold CV: downloads the Beck et al. (2018) Koppen-Geiger raster, clusters coordinates into villages via DBSCAN within each climate zone, computes three-tier hierarchical statistics, and trains LightGBM per target per fold. Saves all 195 model files (13 targets x 15 folds) as native LightGBM `.txt` files, plus a single `pipeline_state.pkl` containing village clustering, hierarchical stats, feature definitions, and capping bounds. Run once; inference is handled by the separate inference notebook.

---

## Modelling Notebooks

### 1. RHEA Koeppen-Geiger Stratified Clustering
**File:** `rhea-koeppen-geiger-stratified-clustering.ipynb`
**Runtime:** ~12 min (GPU P100, Kaggle)
**Output:** `rhea_sub_village_fin.csv`
**Dependencies:** None (self-contained)

Assigns each coordinate a Koppen-Geiger climate zone using the Beck et al. (2018) 1 km raster, then clusters points into "villages" via 2 km haversine DBSCAN within each zone. Three-tier hierarchical statistics (village x depth, village-all, KG zone x depth) are computed and used as features for per-target LightGBM models with 5-fold CV. Predictions are capped using hierarchical bounds that fall back from village to zone to global ranges.

---

### 2. w/Priors -- RHEA Koeppen-Geiger Stratified Clustering
**File:** `w-priors-rhea-koeppen-geiger-stratified-clustering.ipynb`
**Runtime:** ~12 min (GPU P100, Kaggle)
**Output:** `rhea_sub_village_fin_v2.csv`
**Dependencies:** None (self-contained)

Same KG-stratified village pipeline as above, with an additional step: proximity-confidence regularization. For test coordinates that lack nearby training observations, predictions fall back to spatially calibrated geochemical baselines with stochastic perturbation, reducing overconfident extrapolation in data-sparse regions.

---

### 3. Spatial Predictions Using Ensemble Machine Learning
**File:** `spatial-predictions-using-ensemble-machine-learnin.ipynb`
**Runtime:** ~19 min (TPU v5e-8, Kaggle)
**Output:** `rhea_sub_ridge.csv`
**Dependencies:** Dataset `DATA_RHEA_spatial_eml_v2` (from Notebook B)

Builds a rich spatial feature set including oblique coordinate projections, KNN distance features, PCA components, iSDAsoil raster extractions, and neighbor target-value statistics. Trains six independent base learners (Random Forest, Extra Trees, XGBoost, LightGBM, CatBoost, Ridge) per target using spatial block GroupKFold CV. Each model produces its own submission; the Ridge output is used in the final ensemble.

---

### 4. Kenya-Boosted Regionalized Ensemble
**File:** `NOTEBOOK_colab__Fin_Rhea_Soil_Nutrient_Prediction_Kenya_Boosted_Reg.ipynb`
**Runtime:** ~67 min (TPU v5e-8, Google Colab)
**Output:** `submission_Fin_Rhea_Soil_Nutrient_Prediction_Kenya_Boosted_Reg.csv`
**Dependencies:** None (downloads supplementary data at runtime)

Addresses the Kenya data gap (1,230 test points but very few training samples) by fusing three supplementary Kenya datasets as auxiliary features: OCP Kenya soil samples via KNN, county-level aggregate statistics, and iSDA S3 raster predictions. Trains hierarchical per-region models (country x KG zone) using a stacked ensemble of LightGBM, XGBoost, Random Forest, and Ridge, so each test point gets a model trained on geographically and climatically relevant data.

---

### 5. Approach from Winning Solution for AfSIS 2014 Competition
**File:** `apprch-frm-winning-solution-for-afsis-2014-compe.ipynb`
**Runtime:** ~2 hr 9 min (CPU only, Kaggle)
**Output:** `rhea_ensemble_submission.csv`
**Dependencies:** Dataset `DATA_MODIS/SRTM/CHIRPS/is/AfSIS` (from Notebook A)

Adapts the winning methodology from the [AfSIS Soil Properties competition](https://www.kaggle.com/competitions/afsis-soil-properties/overview). Assembles a feature matrix from SRTM elevation/terrain, CHIRPS rainfall, AfSIS nearest-neighbor IDW statistics, and iSDA raster extractions. Per target, trains multiple model variants -- LightGBM (full features, PCA-50, top-80 by variance), MLP ensembles, subsampled SVR, and Ridge -- then combines them via weighted averaging with heavier weight on the LightGBM OOF-validated models.

---

### C-inf. KG-Stratified Villages (Inference)
**File:** `kg-stratified-villages-inference.ipynb`
**Runtime:** Seconds (model loading + prediction)
**Output:** `rhea_sub_village_fin.csv`
**Dependencies:** Trained models and artifacts from Notebook C

Loads the 195 pre-trained LightGBM models and pipeline artifacts saved by the training notebook. Assigns KG climate zones to the test coordinates, matches them to the trained village clusters, builds the same hierarchical feature set, averages predictions across all 15 folds per target, applies hierarchical capping, and writes the submission CSV.

---

### 6. Bringing Everything Together
**File:** `bringing-everything-together.ipynb`
**Output:** Final ensemble submission
**Dependencies:** Outputs from Notebooks 1-5 (and/or C-inf)

Loads the five submissions above and blends them into a single final prediction. **Run this notebook last.**

---

## Execution Order

```
[Step 1 -- Data Prep & Training (run before their dependents)]
  A.    MODIS/SRTM/CHIRPS/iSDA/AfSIS + BART     -->  feeds Notebook 5
  B.    RHEA Spatial EML v2                       -->  feeds Notebook 3
  C.    KG-Stratified Villages (Training)         -->  feeds Notebook C-inf

[Step 2 -- Modelling (run in any order, respecting dependencies above)]
  1.    RHEA Koeppen-Geiger Stratified Clustering
  2.    w/Priors -- RHEA Koeppen-Geiger Stratified Clustering
  3.    Spatial Predictions Using Ensemble Machine Learning    (needs B)
  4.    Kenya-Boosted Regionalized Ensemble
  5.    Apprch frm Winning Solution for AfSIS 2014 Compe      (needs A)
  C-inf. KG-Stratified Villages (Inference)                   (needs C)

[Step 3 -- Final Blend (run last)]
  6.    Bringing Everything Together
```
