# Rhea Soil Nutrient Prediction Challenge: My Complete Approach

## 🎯 The Aim

Soil health is the foundation of food security, but across Africa, laboratory testing is expensive, slow, and often unavailable to smallholder farmers. Without knowing what nutrients their soil lacks, farmers cannot make informed decisions about fertilizers or crop selection.

**The challenge**: Predict 13 soil nutrients (Aluminum, Boron, Calcium, Copper, Iron, Potassium, Magnesium, Manganese, Nitrogen, Sodium, Phosphorus, Sulfur, and Zinc) at 3,196 locations across Africa using only coordinates and depth information.


**The goal**: Help Rhea and Digital Africa build a tool that can estimate soil health anywhere, giving farmers actionable insights without expensive lab tests.

---

## 🗺️ My Journey: From Raw Data to Final Solution

### Step 1: Gathering Intelligence from Space (The Data Collection Phase)

I knew that soil properties don't exist in isolation—they're shaped by climate, terrain, vegetation, and human activity over thousands of years. So my first task was to bring the environment to my laptop.

**I built four parallel extraction pipelines**, each running for days in Google Earth Engine:

**Core Environmental Data**:
- **NASA SRTM**: Elevation, slope, aspect, and terrain ruggedness
- **CHIRPS rainfall**: 10 years of pentadal rainfall data, including mean, standard deviation, seasonal patterns (wet/dry seasons), and maximum events
- **MODIS temperature**: Land surface temperature day and night, seasonal variations, temperature extremes
- **MODIS vegetation**: NDVI and EVI indices showing plant health and biomass, including mean, standard deviation, min/max, and seasonal patterns
- **Sentinel-2 imagery**: Spectral bands and derived indices for clay minerals, iron content, salinity, and water stress
- **Nighttime lights**: Human activity and urbanization proxy from NOAA satellites

**Deep Soil Properties**:
- **SoilGrids**: Global soil property estimates at multiple depths (0-5cm, 5-15cm, 15-30cm, 30-60cm) including cation exchange capacity, pH, organic carbon, nitrogen, clay content, sand content, and bulk density

**Global Climate Patterns**:
- **WorldClim**: Long-term climate averages including annual precipitation, wettest/driest month, precipitation seasonality, temperature seasonality, and temperature range
- **TerraClimate**: Monthly water balance data including soil moisture, runoff, Palmer drought index, potential evapotranspiration, actual evapotranspiration, and water deficit

**Specialized Signals**:
- **Sentinel-1 radar**: Soil moisture indicators, surface roughness, seasonal flood patterns, and radar vegetation index (RVI) that penetrates clouds
- **Topographic Wetness Index**: Where water accumulates in the landscape—critical for manganese and iron chemistry
- **Fire frequency**: MODIS burned area data showing fire return intervals—important for nitrogen and sulfur cycling
- **Water dynamics**: JRC Global Surface Water showing occurrence, seasonality, and recurrence of surface water

**The result**: Over 1,000 environmental features for every single location—a rich digital portrait of the African landscape.

---

### Step 2: The Golden Discovery (64% of Test Points Share a Secret)

While exploring the data, I made an observation that would become the cornerstone of my solution. I overlaid training and test points on a map of Africa and noticed something extraordinary:

**64% of test locations had a training sample at the exact same coordinates, just at the opposite depth.**

Think about what this means. If you have a soil sample at 0-20cm depth at a specific farm, and you need to predict nutrients at 20-50cm at that exact same farm, you're not guessing blindly. The soil at 50cm depth is chemically related to the soil at 20cm depth—they share the same parent material, same climate history, same drainage patterns.

I built a special feature around this insight:
- For every point, I looked for its "twin" at the opposite depth
- If an exact match existed, I could use those values directly
- If not, I estimated using nearby points at that depth
- I also created ratio and difference features between depths

This single feature became my most powerful predictor. For nutrients like Calcium, just knowing the value at the opposite depth explained over 40% of the variation.

---

### Step 3: Learning from Neighbors (Multi-Scale Spatial Modeling)

Soil doesn't exist in isolation. A point in Kenya is influenced by soils hundreds of kilometers away, but the influence weakens with distance. I built a sophisticated spatial learning system:

**Multi-scale Inverse Distance Weighting (IDW)**:
- **Different powers** (1, 2, 3): How quickly influence decays with distance
- **Different neighbor counts** (5, 15, 30, 60, 100): How many neighbors to consider
- **Different decay scales** (20km, 50km, 150km): Exponential decay kernels
- Total combinations: 3 powers × 5 neighbor counts × 3 decay scales = 45 different spatial estimates per nutrient

**Local statistics**:
- Mean, standard deviation, range, and percentiles of nearby values
- Number of samples within 5km, 30km, and 100km
- Distance to nearest neighbor as a reliability indicator

**Depth-stratified spatial modeling**:
- Separate IDW calculations for 0-20cm and 20-50cm layers
- Cross-depth ratios and differences (e.g., how does Calcium change with depth?)
- Reliability scores based on density of samples at each depth

**The result**: A rich set of spatial features that capture both local patterns and regional trends.

---

### Step 4: Understanding Soil Chemistry (Domain Knowledge Integration)

I didn't just throw data at models—I encoded fundamental soil science principles:

**For Iron and Aluminum** (acidic soil indicators):
- Iron availability increases in acidic soils (low pH)
- Aluminum toxicity occurs when pH drops below 5.5
- Laterite soils (tropical) are rich in iron oxides
- Waterlogged conditions create reducing environments that affect iron chemistry

**For Calcium and Magnesium** (base cations):
- High rainfall leaches these nutrients from soil
- Clay-rich soils hold them better
- Arid regions accumulate them near the surface
- Parent material (rock type) determines baseline levels

**For Nitrogen** (the cycling nutrient):
- Organic matter content drives nitrogen availability
- Temperature affects mineralization rates
- Fire returns nitrogen to atmosphere
- Vegetation inputs (NDVI) indicate organic nitrogen sources

**For Phosphorus** (the limiting nutrient):
- Fixed by iron and aluminum in acid soils
- Fixed by calcium in alkaline soils
- Most available at near-neutral pH (6.2-7.0)
- Organic matter provides slow-release phosphorus

**For trace elements** (Boron, Zinc, Copper):
- Strongly bound to organic matter
- Availability peaks in specific pH ranges
- Sandy soils lose them through leaching
- Fire can volatilize some elements

I created over 80 process-based features that capture these relationships mathematically.

---

### Step 5: Clustering Africa into Soil Zones

Africa is not uniform—soils in the Sahel behave differently from soils in the Congo Basin or the East African highlands. I grouped the continent into meaningful zones:

- **K-means clustering** of all points (training + test) into 150 clusters
- For each cluster, calculated statistics for every nutrient: mean, standard deviation, median, 10th percentile, 90th percentile
- For each point, added features showing how it compares to its cluster
- Added distance to cluster center and cluster size as reliability indicators

This allowed the model to learn regional patterns—if you're in the Ethiopian highlands, your soil behaves like other Ethiopian highland soils, not like coastal soils.

---

### Step 6: Per-Nutrient Strategy (One Size Does Not Fit All)

Different nutrients have different data availability and different chemical behaviors. I created individual strategies for each:

**Dense nutrients** (Al, Ca, Fe, K, Mg, Mn, N):
- ~2,500-3,500 training samples
- More complex models with 250 selected features
- Deeper trees, more iterations
- Full ensemble of all three model types

**Sparse nutrients** (B, Na, P, S, Zn):
- Only ~1,900 training samples
- Simpler models with 180 selected features
- Shallow trees, fewer iterations
- Stronger regularization to prevent overfitting
- More weight on spatial features, less on complex interactions

**Feature selection per nutrient**:
- Used LightGBM feature importance to select top features for each nutrient
- Dense nutrients: top 250 features
- Sparse nutrients: top 180 features
- This reduced noise and improved generalization

---

### Step 7: Geochemical Chaining (Nutrients Helping Nutrients)

Nutrients don't exist independently—they interact. Iron affects phosphorus availability. Calcium and magnesium compete for uptake. I built a chaining system where predictions for one nutrient become features for predicting others:

- Predicted nutrients in order of importance: Fe → Al → Ca → N → Cu → Mg → K → Mn → Na → B → S → P → Zn
- Used 1-fold cross-validation to generate out-of-fold predictions
- Created ratio and product features between related nutrients (Fe/Al ratio, Ca/Mg ratio, N/P ratio)
- This captured geochemical relationships that single-nutrient models would miss

---

### Step 8: The Ensemble Engine (Three Brains Are Better Than One)

For each nutrient, I trained three different model types:

**LightGBM** (gradient boosting):
- Fast, handles missing values well
- Good with categorical features
- Hyperparameters tuned per nutrient
- 5,000-10,000 trees depending on nutrient

**XGBoost** (extreme gradient boosting):
- More regularized than LightGBM
- Better with sparse data
- Different hyperparameter optimization
- Complementary strengths

**CatBoost** (categorical boosting):
- Handles categorical features naturally
- Different splitting logic
- Often captures patterns others miss

**Training process**:
- 5-fold cross-validation with custom groups (geographic + island clusters)
- Within each fold: 85/15 internal validation split for early stopping
- Each fold produces a separate model (5 models per nutrient per algorithm)
- Test predictions averaged across all 5 folds for stability

**Total models**: 13 nutrients × 3 algorithms × 5 folds = 195 individual models

---

### Step 9: Intelligent Blending (Finding the Perfect Mix)

After getting predictions from all three algorithms, I needed to combine them optimally:

**Ridge stacking**:
- Trained a positive Ridge regression on out-of-fold predictions
- Forces weights to be positive (no negative contributions)
- Learns optimal combination of LGBM, XGBoost, and CatBoost

**Nelder-Mead optimization**:
- Tested multiple starting weight combinations
- Optimized blend of all 4 components (3 algorithms + Ridge)
- Found weights that minimize RMSE on validation data
- Different optimal blends for different nutrients

**The result**: For each nutrient, a custom ensemble that knows which algorithms to trust and how much.

---

### Step 10: Conservative Override (Safety Net for High-Confidence Points)

For test points extremely close to training points, I didn't want to rely on model predictions alone:

- **Exact matches** (<1m): Directly used training values
- **Very close** (<50m): Weighted average of nearest neighbors
- **Close** (<200m): Blend of neighbor values (90% weight) and model (10%)
- **Near** (<1km): Blend of neighbor values (75% weight) and model (25%)

This safety net ensures that when we have high-confidence spatial information, we use it directly.

---

### Step 11: The Zero Mask (Respecting the Data)

The challenge provided a special file—TargetPred_To_Keep.csv—that indicated which predictions should actually be zero. Some nutrients are truly absent in certain soils, and we shouldn't predict positive values there.

I applied this mask at the very end, setting specific predictions to zero where the data said they should be absent.

---

### Step 12: Validation and Final Touches

**Cross-validation design**:
- Created 60 geographic clusters plus 18 "island" clusters for isolated points
- Ensured training and validation points were spatially separated
- No spatial leakage between folds

**Test-time augmentation**:
- Slightly perturbed coordinates (±0.01°) and averaged predictions
- Made model more robust to coordinate uncertainty

**Submission format**:
- CRITICAL: Column names must be 'Target_Al', 'Target_B', etc. (not just 'Al')
- This single detail was worth ~0.15 in score

---

## ✅ The Final Solution

A sophisticated hybrid system combining:

| Component | Description |
|-----------|-------------|
| **Environmental features** | 1,000+ satellite-derived variables |
| **Depth-pair matching** | The 64% signal—most powerful single feature |
| **Multi-scale IDW** | 45 spatial estimates per nutrient |
| **Soil process features** | 80+ domain knowledge features |
| **Cluster statistics** | 150 soil zones with zone-specific patterns |
| **Geochemical chaining** | Nutrient interactions captured |
| **Per-nutrient ensembles** | 195 individual models (13×3×5) |
| **Intelligent blending** | Ridge + Nelder-Mead optimization |
| **Conservative lookup** | Safety net for near neighbors |
| **Zero mask** | Respects known absences |

**The result**: A model that understands both the broad patterns of African soils and the local nuances at each test location. It knows when to trust neighbors, when to trust satellite data, and when to blend multiple sources of information.

---

## 📊 Why This Approach Worked

1. **Respected data reality**: Different strategies for dense vs sparse nutrients
2. **Leveraged the hidden structure**: The 64% depth-pair signal was game-changing
3. **Multi-scale thinking**: Captured patterns from 5m to 500km
4. **Domain knowledge**: Soil chemistry isn't just statistics—it's science
5. **Ensemble robustness**: 195 models working together, not one model failing alone
6. **Safety mechanisms**: Conservative overrides for high-confidence cases

The final model doesn't just predict numbers—it understands African soils. And that understanding can now help farmers across the continent make better decisions about their land.