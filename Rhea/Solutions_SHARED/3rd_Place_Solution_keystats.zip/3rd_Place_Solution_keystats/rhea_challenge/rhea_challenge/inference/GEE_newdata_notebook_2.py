"""
GEE_newdata_notebook_2.py
=========================
NEW DATA EXTRACTION — NOTEBOOK 2 of 2
Run both notebooks simultaneously in separate Colab tabs.

EXTRACTIONS IN THIS NOTEBOOK:
  RUN_SAR         → NewData_sar.csv
  RUN_SOIL_CONSTR → NewData_soil_constraints.csv
  RUN_TWI         → NewData_twi.csv
"""

import ee
import pandas as pd
import numpy as np
from tqdm import tqdm
import time
import warnings
warnings.filterwarnings('ignore')

# ── TOGGLE ────────────────────────────────────────────────────────────────────
RUN_SAR         = True
RUN_SOIL_CONSTR = True
RUN_TWI         = True

START = '2008-01-01'
END   = '2018-12-31'

# ── INIT ──────────────────────────────────────────────────────────────────────
try:
    ee.Initialize(project='radiant-cycle-429609-g2')
    print("✅ Earth Engine initialized")
except:
    ee.Initialize()

NewData = pd.read_csv('../additional_test_dataset.csv')   # ← your new data file
print(f"NewData: {NewData.shape}")


# ── SHARED EXTRACTOR ──────────────────────────────────────────────────────────
def extract(df, img, batch_size=50, scale=1000, label=""):
    all_rows = []; n = (len(df) + batch_size - 1) // batch_size
    band_names = None; failed = 0
    print(f"\n🛰️  {label}: {len(df)} pts | {n} batches | scale={scale}m")
    for bi in tqdm(range(n), desc=label):
        s = bi * batch_size; e = min(s + batch_size, len(df))
        batch = df.iloc[s:e]; rows = []; ok = False
        for attempt in range(4):
            try:
                fc = ee.FeatureCollection([
                    ee.Feature(ee.Geometry.Point([float(r['Longitude']), float(r['Latitude'])]),
                               {'_i': i})
                    for i, (_, r) in enumerate(batch.iterrows())])
                res = img.reduceRegions(collection=fc, reducer=ee.Reducer.first(),
                          scale=scale).getInfo()['features']
                if band_names is None and res:
                    band_names = [k for k in res[0]['properties'] if k != '_i']
                idx_map = {f['properties']['_i']: {k: v for k, v in f['properties'].items() if k != '_i'}
                           for f in res}
                for i in range(len(batch)):
                    rows.append(idx_map.get(i, {k: np.nan for k in (band_names or [])}))
                ok = True; break
            except Exception as ex:
                if attempt < 3:
                    w = 10 * (attempt + 1)
                    print(f"\n  ⚠️  batch {bi} attempt {attempt+1}: {str(ex)[:80]} — wait {w}s")
                    time.sleep(w)
                else:
                    failed += 1
                    rows = [{k: np.nan for k in (band_names or [])} for _ in range(len(batch))]
        all_rows.extend(rows)
        time.sleep(0.3)
    if not band_names:
        print("  ⚠️  nothing extracted"); return pd.DataFrame()
    df_out = pd.DataFrame(all_rows, columns=band_names)
    print(f"  ✅ {label}: {df_out.shape[1]} bands | {100*df_out.notna().mean().mean():.1f}% non-null | failed={failed}")
    return df_out


def run(tag, build_fn, out_csv, batch_size=50, scale=1000):
    print(f"\n{'='*60}\n{tag}\n{'='*60}")
    try:
        existing = pd.read_csv(out_csv)
        print(f"  ✅ {out_csv} exists — {existing.shape} — skipping"); return
    except:
        pass
    img = build_fn()
    result = extract(NewData, img, batch_size, scale, tag)
    if not result.empty:
        result.to_csv(out_csv, index=False)
        print(f"  💾 {out_csv}")


# ── IMAGE BUILDERS ────────────────────────────────────────────────────────────

def build_sar():
    print("🔬 Building Sentinel-1 SAR image (2015-2018)...")
    s1 = (ee.ImageCollection('COPERNICUS/S1_GRD')
            .filterDate('2015-01-01', END)
            .filter(ee.Filter.eq('instrumentMode', 'IW'))
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
            .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
            .select(['VV', 'VH']))

    vv_mean  = s1.select('VV').mean().rename('s1_vv_mean')
    vh_mean  = s1.select('VH').mean().rename('s1_vh_mean')
    vv_std   = s1.select('VV').reduce(ee.Reducer.stdDev()).rename('s1_vv_std')
    vh_std   = s1.select('VH').reduce(ee.Reducer.stdDev()).rename('s1_vh_std')
    vv_vh    = vv_mean.subtract(vh_mean).rename('s1_vv_vh_ratio')
    cross    = vh_mean.subtract(vv_mean).rename('s1_cross_ratio')
    vv_lin   = vv_mean.expression('10 ** (VV / 10)', {'VV': vv_mean})
    vh_lin   = vh_mean.expression('10 ** (VH / 10)', {'VH': vh_mean})
    rvi      = vh_lin.multiply(4).divide(vv_lin.add(vh_lin).add(1e-6)).rename('s1_rvi')
    s1_wet   = s1.filter(ee.Filter.calendarRange(10, 4, 'month'))
    s1_dry   = s1.filter(ee.Filter.calendarRange(5,  9, 'month'))
    vv_wet   = s1_wet.select('VV').mean().rename('s1_vv_wet')
    vv_dry   = s1_dry.select('VV').mean().rename('s1_vv_dry')
    vh_wet   = s1_wet.select('VH').mean().rename('s1_vh_wet')
    vh_dry   = s1_dry.select('VH').mean().rename('s1_vh_dry')
    vv_delta = vv_wet.subtract(vv_dry).rename('s1_vv_seasonal_delta')
    vh_delta = vh_wet.subtract(vh_dry).rename('s1_vh_seasonal_delta')
    vv_p95   = s1.select('VV').reduce(ee.Reducer.percentile([95])).rename('s1_vv_p95')
    vv_flood = vv_p95.subtract(vv_mean).rename('s1_vv_flood_proxy')

    print("  ✅ SAR Sentinel-1 15 bands")
    return ee.Image.cat([
        vv_mean, vh_mean, vv_std, vh_std, vv_vh, cross, rvi,
        vv_wet, vv_dry, vh_wet, vh_dry,
        vv_delta, vh_delta, vv_p95, vv_flood
    ])


def build_soil_constraints():
    print("🔬 Building soil constraints image...")
    burn      = ee.ImageCollection('MODIS/061/MCD64A1').filterDate(START, END).select('BurnDate')
    burn_freq = burn.map(lambda i: i.gt(0).rename('burned')).sum().rename('fire_frequency')
    burn_rec  = (burn.filterDate('2015-01-01', END)
                   .map(lambda i: i.gt(0)).sum().rename('fire_freq_recent'))
    gsw        = ee.Image('JRC/GSW1_4/GlobalSurfaceWater')
    water_occ  = gsw.select('occurrence').rename('water_occurrence')
    water_seas = gsw.select('seasonality').rename('water_seasonality')
    water_recr = gsw.select('recurrence').rename('water_recurrence')
    ndvi_long  = (ee.ImageCollection('MODIS/061/MOD13A2').filterDate(START, END)
                    .select('NDVI').mean().multiply(0.0001).rename('ndvi_integrated'))
    evi_wet    = (ee.ImageCollection('MODIS/061/MOD13A2').filterDate(START, END)
                    .filter(ee.Filter.calendarRange(10, 4, 'month'))
                    .select('EVI').mean().multiply(0.0001).rename('evi_wet'))
    soc_deep   = (ee.Image('OpenLandMap/SOL/SOL_ORGANIC-CARBON_USDA-6A1C_M/v02')
                    .select(['b10','b30','b60','b100'])
                    .rename(['soc_30cm','soc_60cm','soc_100cm','soc_200cm']))
    texture    = ee.Image('OpenLandMap/SOL/SOL_TEXTURE-CLASS_USDA-TT_M/v02')
    tex_0cm    = texture.select('b0').rename('texture_0cm')
    tex_30cm   = texture.select('b30').rename('texture_30cm')
    tex_grad   = texture.select('b0').subtract(texture.select('b60')).rename('texture_depth_grad')
    ls8 = (ee.ImageCollection('LANDSAT/LC08/C02/T1_L2').filterDate(START, END)
             .filter(ee.Filter.lt('CLOUD_COVER', 20))
             .select(['SR_B2','SR_B4','SR_B5','SR_B6','SR_B7']).median()
             .multiply(2.75e-5).add(-0.2))
    ls_red=ls8.select('SR_B4'); ls_blue=ls8.select('SR_B2')
    ls_nir=ls8.select('SR_B5'); ls_sw1=ls8.select('SR_B6'); ls_sw2=ls8.select('SR_B7')
    redness  = ls_red.subtract(ls_blue).divide(ls_red.add(ls_blue).add(1e-6)).rename('redness_idx')
    laterite = ls_red.divide(ls_nir.add(1e-6)).rename('laterite_idx')
    fe_oxide = ls_sw2.divide(ls_nir.add(1e-6)).rename('fe_oxide_idx')
    cmr      = ls_sw1.divide(ls_sw2.add(1e-6)).rename('clay_mineral_ratio')

    print("  ✅ Soil constraints 20 bands")
    return ee.Image.cat([
        burn_freq, burn_rec,
        water_occ, water_seas, water_recr,
        ndvi_long, evi_wet,
        soc_deep, tex_0cm, tex_30cm, tex_grad,
        redness, laterite, fe_oxide, cmr
    ])


def build_twi():
    print("🔬 Building TWI + NASADEM terrain image...")
    flow_acc = ee.Image('WWF/HydroSHEDS/15ACC').select('b1')
    srtm     = ee.Image('USGS/SRTMGL1_003')
    slp_deg  = ee.Terrain.slope(srtm)
    slp_rad  = slp_deg.multiply(np.pi / 180)
    tan_slp  = slp_rad.tan().add(0.001)
    cell_a   = ee.Number(450 * 450)
    twi_real = flow_acc.add(1).multiply(cell_a).divide(tan_slp).log().rename('twi_real')
    nasadem  = ee.Image('NASA/NASADEM_HGT/001').select('elevation').rename('nasadem_elev')
    nas_slp  = ee.Terrain.slope(nasadem).rename('nasadem_slope')
    nas_asp  = ee.Terrain.aspect(nasadem).rename('nasadem_aspect')
    nas_rgh  = nasadem.reduceNeighborhood(ee.Reducer.stdDev(), ee.Kernel.square(3)).rename('nasadem_roughness')
    loc_mean = nasadem.reduceNeighborhood(ee.Reducer.mean(), ee.Kernel.circle(5))
    valley   = loc_mean.subtract(nasadem).rename('valley_idx')
    emin     = nasadem.reduceNeighborhood(ee.Reducer.min(), ee.Kernel.circle(30))
    emax     = nasadem.reduceNeighborhood(ee.Reducer.max(), ee.Kernel.circle(30))
    basin    = nasadem.subtract(emin).divide(emax.subtract(emin).add(0.1)).rename('basin_position')
    emin_b   = emin.rename('elev_min_10km')
    emax_b   = emax.rename('elev_max_10km')
    twi_high = twi_real.gt(12).rename('twi_high_risk')

    print("  ✅ TWI + NASADEM 10 bands")
    return ee.Image.cat([
        twi_real, twi_high,
        nasadem, nas_slp, nas_asp, nas_rgh,
        valley, basin, emin_b, emax_b
    ])


# ── RUN ───────────────────────────────────────────────────────────────────────
if RUN_SAR:
    run('SAR',         build_sar,              'NewData_sar.csv',               batch_size=50,  scale=10)
if RUN_SOIL_CONSTR:
    run('SOIL_CONSTR', build_soil_constraints, 'NewData_soil_constraints.csv',  batch_size=50,  scale=30)
if RUN_TWI:
    run('TWI',         build_twi,              'NewData_twi.csv',               batch_size=100, scale=500)

print("\n✅ Notebook 2 done.")
