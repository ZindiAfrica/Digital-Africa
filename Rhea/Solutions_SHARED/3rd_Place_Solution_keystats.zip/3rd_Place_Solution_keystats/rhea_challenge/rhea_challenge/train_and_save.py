#train_and_save.py
# =================
# Full training pipeline — trains and saves everything in ONE pass.
# No separate saving step needed. Inference can run immediately after this.
#
# USAGE:
#     python train_and_sa#ve.py
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# IMPORTS
# ─────────────────────────────────────────────────────────────────────────────
import os, pickle, json
import pandas as pd
import numpy as np
import lightgbm as lgb
import xgboost as xgb
import catboost as cb
from pathlib import Path
from sklearn.preprocessing import RobustScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans
from sklearn.model_selection import GroupKFold
from sklearn.linear_model import Ridge
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
TARGET_COLS = ['Al','B','Ca','Cu','Fe','K','Mg','Mn','N','Na','P','S','Zn']
SPARSE_NUTS = ['B','Na','P','S','Zn']
DENSE_NUTS  = ['Al','Ca','Cu','Fe','K','Mg','Mn','N']

METRICS = {
    'Ca':{'scaling':4632.36,'weight':0.10}, 'Cu':{'scaling':4.0,  'weight':0.10},
    'B': {'scaling':1.0,   'weight':0.05},  'Fe':{'scaling':80.0, 'weight':0.10},
    'K': {'scaling':532.0, 'weight':0.10},  'Mg':{'scaling':672.0,'weight':0.10},
    'Mn':{'scaling':128.0, 'weight':0.10},  'N': {'scaling':2.0,  'weight':0.10},
    'P': {'scaling':12.0,  'weight':0.05},  'Al':{'scaling':487.0,'weight':0.10},
    'Na':{'scaling':36.0,  'weight':0.05},  'S': {'scaling':7.0,  'weight':0.025},
    'Zn':{'scaling':1.0,   'weight':0.025},
}

CHAIN_ORDER = ['Fe','Al','Ca','N','Cu','Mg','K','Mn','Na','B','S','P','Zn']
CHAIN_PAIRS = [('Fe','Al'),('Ca','Mg'),('Ca','K'),('N','P'),('Fe','Mn'),
               ('K','Mg'),('S','Zn'),('P','Zn'),('N','K'),('Ca','Na'),
               ('Fe','P'),('Al','P'),('Mn','Fe'),('Al','Fe'),('Mg','K')]

N_FOLDS   = 5
ES_ROUNDS = 150
SEP = "=" * 72

SAVE_DIR = Path('saved_model')
os.makedirs(SAVE_DIR / 'scalers',         exist_ok=True)
os.makedirs(SAVE_DIR / 'spatial',         exist_ok=True)
os.makedirs(SAVE_DIR / 'chain_models',    exist_ok=True)
os.makedirs(SAVE_DIR / 'nutrient_models', exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────
def rmse(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    return float(np.sqrt(np.mean((a - b)**2)))

def safe_log1p(x):
    return np.log1p(np.clip(np.asarray(x, float), 0, None))

def safe_expm1(x):
    return np.expm1(np.clip(np.asarray(x, float), -10, 20))

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1,lon1,lat2,lon2 = map(np.radians,[lat1,lon1,lat2,lon2])
    dlat=lat2-lat1; dlon=lon2-lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2
    return 2*R*np.arcsin(np.sqrt(np.clip(a,0,1)))

# ─────────────────────────────────────────────────────────────────────────────
# SPATIAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def nn_distances_km(tr_coords, te_coords):
    nn = NearestNeighbors(n_neighbors=2, metric='haversine')
    nn.fit(np.radians(tr_coords))
    d_tr,_ = nn.kneighbors(np.radians(tr_coords))
    d_te,_ = nn.kneighbors(np.radians(te_coords))
    return d_tr[:,1]*6371, d_te[:,0]*6371

def multi_scale_idw(tr_coords, te_coords, y_train,
                    powers=(1,2,3), ks=(5,15,30,60,100),
                    decay_scales=(20,50,150)):
    if y_train.ndim == 1: y_train = y_train[:,None]
    n_cols = y_train.shape[1]
    k_max  = min(max(ks)+1, len(tr_coords)-1)
    nn = NearestNeighbors(n_neighbors=k_max+1, metric='haversine')
    nn.fit(np.radians(tr_coords))
    results = {}
    for tag, coords, skip_self in [('tr',tr_coords,True),('te',te_coords,False)]:
        d_rad, idx = nn.kneighbors(np.radians(coords))
        if skip_self:
            d_rad = d_rad[:,1:k_max+1]; idx = idx[:,1:k_max+1]
        else:
            d_rad = d_rad[:,:k_max];    idx = idx[:,:k_max]
        d_km = d_rad * 6371
        out = {}
        for k in ks:
            k_use = min(k, d_km.shape[1]); dk=d_km[:,:k_use]; ik=idx[:,:k_use]; yk=y_train[ik]
            for pw in powers:
                w=1.0/(dk**pw+1e-8); w/=w.sum(axis=1,keepdims=True)+1e-12
                pred=np.einsum('ij,ijk->ik',w,yk)
                for j in range(n_cols): out[f'idw_k{k}_p{pw}_{TARGET_COLS[j]}']=pred[:,j]
        k30=min(30,d_km.shape[1]); d30=d_km[:,:k30]; i30=idx[:,:k30]; y30=y_train[i30]
        for ds in decay_scales:
            dw=np.exp(-d30/ds)/(d30**2+1e-8); dw/=dw.sum(axis=1,keepdims=True)+1e-12
            pred=np.einsum('ij,ijk->ik',dw,y30)
            for j in range(n_cols): out[f'idw_decay{ds}_{TARGET_COLS[j]}']=pred[:,j]
        for j in range(n_cols):
            yj=y30[:,:,j]
            out[f'local_mean_k30_{TARGET_COLS[j]}']=yj.mean(axis=1)
            out[f'local_std_k30_{TARGET_COLS[j]}']=yj.std(axis=1)
            out[f'local_range_k30_{TARGET_COLS[j]}']=yj.max(axis=1)-yj.min(axis=1)
            out[f'local_p25_k30_{TARGET_COLS[j]}']=np.percentile(yj,25,axis=1)
            out[f'local_p75_k30_{TARGET_COLS[j]}']=np.percentile(yj,75,axis=1)
        nn1=d_km[:,0]
        out['nn1_km']=nn1; out['nn5_km']=d_km[:,min(4,d_km.shape[1]-1)]
        out['nn_mean30_km']=d_km[:,:30].mean(axis=1)
        out['rel_20km']=np.exp(-nn1/20.); out['rel_50km']=np.exp(-nn1/50.)
        out['rel_100km']=np.exp(-nn1/100.)
        out['n_within_5km']=(d_km<5).sum(axis=1).astype(float)
        out['n_within_30km']=(d_km<30).sum(axis=1).astype(float)
        out['n_within_100km']=(d_km<100).sum(axis=1).astype(float)
        out['is_exact']=(nn1<0.1).astype(float)
        out['is_near_30km']=(nn1<30).astype(float)
        out['is_ood_100km']=(nn1>100).astype(float)
        results[tag] = pd.DataFrame(out).reset_index(drop=True)
    return results['tr'], results['te']

def depth_stratified_idw(train_df, test_df, y_train_filled, k=15, power=2):
    depths=['0-20','20-50']; n_nut=len(TARGET_COLS)
    tr_out={}; te_out={}
    for di,depth in enumerate(depths):
        trm=(train_df['Depth_cm']==depth).values; tem=(test_df['Depth_cm']==depth).values
        if trm.sum()<k+2: continue
        tc=train_df.loc[trm,['Latitude','Longitude']].values; yd=y_train_filled[trm]
        k_use=min(k+1,trm.sum()-1)
        nn=NearestNeighbors(n_neighbors=k_use,metric='haversine').fit(np.radians(tc))
        d_tr,i_tr=nn.kneighbors(np.radians(tc))
        d_km_tr=d_tr[:,1:]*6371; i_tr=i_tr[:,1:]
        w_tr=1.0/(d_km_tr**power+1e-8); w_tr/=w_tr.sum(axis=1,keepdims=True)
        vals_tr=np.einsum('ij,ijk->ik',w_tr,yd[i_tr])
        for j in range(n_nut):
            arr=np.zeros(len(train_df)); arr[trm]=vals_tr[:,j]
            tr_out[f'dep{di}_{TARGET_COLS[j]}']=arr
        tr_out[f'dep{di}_rel']=np.ones(len(train_df))
        tr_out[f'dep{di}_rel'][trm]=np.exp(-d_km_tr[:,0]/50.)
        if tem.sum()>0:
            ec=test_df.loc[tem,['Latitude','Longitude']].values; k_te=min(k,trm.sum())
            nn2=NearestNeighbors(n_neighbors=k_te,metric='haversine').fit(np.radians(tc))
            d_te,i_te=nn2.kneighbors(np.radians(ec)); d_km_te=d_te*6371
            w_te=1.0/(d_km_te**power+1e-8); w_te/=w_te.sum(axis=1,keepdims=True)
            vals_te=np.einsum('ij,ijk->ik',w_te,yd[i_te])
            for j in range(n_nut):
                if f'dep{di}_{TARGET_COLS[j]}' not in te_out:
                    te_out[f'dep{di}_{TARGET_COLS[j]}']=np.zeros(len(test_df))
                te_out[f'dep{di}_{TARGET_COLS[j]}'][tem]=vals_te[:,j]
            if f'dep{di}_rel' not in te_out: te_out[f'dep{di}_rel']=np.ones(len(test_df))
            te_out[f'dep{di}_rel'][tem]=np.exp(-d_km_te[:,0]/50.)
    for j in range(n_nut):
        col=TARGET_COLS[j]; k0=f'dep0_{col}'; k1=f'dep1_{col}'
        if k0 in tr_out and k1 in tr_out:
            v0=np.nan_to_num(tr_out[k0]); v1=np.nan_to_num(tr_out[k1])
            tr_out[f'dep_ratio_{col}']=v0/(v1+1e-6); tr_out[f'dep_diff_{col}']=v0-v1
        if k0 in te_out and k1 in te_out:
            v0=np.nan_to_num(te_out[k0]); v1=np.nan_to_num(te_out[k1])
            te_out[f'dep_ratio_{col}']=v0/(v1+1e-6); te_out[f'dep_diff_{col}']=v0-v1
    return (pd.DataFrame(tr_out).fillna(0).reset_index(drop=True),
            pd.DataFrame(te_out).fillna(0).reset_index(drop=True))

def build_depth_pair_features(train_df, test_df, y_train_nan):
    print("  Building depth-pair features...")
    tr_lat=train_df['Latitude'].values; tr_lon=train_df['Longitude'].values
    tr_dep=train_df['Depth_cm'].values
    te_lat=test_df['Latitude'].values;  te_lon=test_df['Longitude'].values
    te_dep=test_df['Depth_cm'].values
    tr_key=np.array([f"{round(a,4)}_{round(b,4)}" for a,b in zip(tr_lat,tr_lon)])
    te_key=np.array([f"{round(a,4)}_{round(b,4)}" for a,b in zip(te_lat,te_lon)])
    n_tr=len(train_df); n_te=len(test_df); n_nut=len(TARGET_COLS)
    loc_dep_idx={(tr_key[i],tr_dep[i]):i for i in range(n_tr)}
    tr_other=np.full((n_tr,n_nut),np.nan); tr_found=np.zeros(n_tr,dtype=bool)
    for i in range(n_tr):
        od='20-50' if tr_dep[i]=='0-20' else '0-20'
        j=loc_dep_idx.get((tr_key[i],od),None)
        if j is not None: tr_other[i]=y_train_nan[j]; tr_found[i]=True
    te_other=np.full((n_te,n_nut),np.nan); te_found=np.zeros(n_te,dtype=bool)
    for i in range(n_te):
        od='20-50' if te_dep[i]=='0-20' else '0-20'
        j=loc_dep_idx.get((te_key[i],od),None)
        if j is not None: te_other[i]=y_train_nan[j]; te_found[i]=True
    print(f"    Train: {tr_found.sum()}/{n_tr} ({100*tr_found.mean():.1f}%)")
    print(f"    Test:  {te_found.sum()}/{n_te} ({100*te_found.mean():.1f}%)")
    for split_label,coords,dep_arr,found_mask,other_arr in [
        ('train',np.c_[tr_lat,tr_lon],tr_dep,tr_found,tr_other),
        ('test', np.c_[te_lat,te_lon],te_dep,te_found,te_other)]:
        missing=~found_mask
        if missing.sum()==0: continue
        miss_coords=coords[missing]; miss_dep=dep_arr[missing]
        for depth in ['0-20','20-50']:
            other_depth='20-50' if depth=='0-20' else '0-20'
            tr_mask_od=tr_dep==other_depth
            if tr_mask_od.sum()<2: continue
            tc_od=np.c_[tr_lat[tr_mask_od],tr_lon[tr_mask_od]]; yv_od=y_train_nan[tr_mask_od]
            k_use=min(10,tr_mask_od.sum()-1)
            nn_od=NearestNeighbors(n_neighbors=k_use,metric='haversine').fit(np.radians(tc_od))
            sub_mask=miss_dep==depth
            if sub_mask.sum()==0: continue
            d_,i_=nn_od.kneighbors(np.radians(miss_coords[sub_mask]))
            d_km=d_*6371; w=1.0/(d_km**2+1e-8); w/=w.sum(axis=1,keepdims=True)
            global_miss_idx=np.where(missing)[0]; sub_idx=global_miss_idx[sub_mask]
            for k_sub,k_global in enumerate(sub_idx):
                vals=yv_od[i_[k_sub]]
                for j in range(n_nut):
                    vj=vals[:,j]; valid_j=~np.isnan(vj)
                    if valid_j.sum()>0:
                        wj=w[k_sub][valid_j]; wj=wj/(wj.sum()+1e-12)
                        other_arr[k_global,j]=np.dot(wj,vj[valid_j])
    tr_df={}; te_df={}; y_means=np.nanmean(y_train_nan,axis=0)
    for j,nut in enumerate(TARGET_COLS):
        tr_df[f'pair_{nut}']=np.where(np.isnan(tr_other[:,j]),y_means[j],tr_other[:,j])
        te_df[f'pair_{nut}']=np.where(np.isnan(te_other[:,j]),y_means[j],te_other[:,j])
        tr_df[f'pair_log_{nut}']=safe_log1p(tr_df[f'pair_{nut}'])
        te_df[f'pair_log_{nut}']=safe_log1p(te_df[f'pair_{nut}'])
    tr_df['pair_found']=tr_found.astype(float); te_df['pair_found']=te_found.astype(float)
    tr_df['is_0_20']=(train_df['Depth_cm']=='0-20').astype(float).values
    te_df['is_0_20']=(test_df['Depth_cm']=='0-20').astype(float).values
    return pd.DataFrame(tr_df).reset_index(drop=True), pd.DataFrame(te_df).reset_index(drop=True)

def cluster_stats_features(train_df, test_df, y_train_nan, n_clusters=150):
    all_coords=np.vstack([train_df[['Latitude','Longitude']].values,
                           test_df[['Latitude','Longitude']].values])
    km=KMeans(n_clusters=n_clusters,random_state=42,n_init=10)
    labs=km.fit_predict(all_coords)
    trl=labs[:len(train_df)]; tel=labs[len(train_df):]
    tr_out={}; te_out={}
    for j,nut in enumerate(TARGET_COLS):
        yv=y_train_nan[:,j]; valid=~np.isnan(yv)
        if valid.sum()<10: continue
        tmp=pd.DataFrame({'c':trl[valid],'v':yv[valid]})
        mn=tmp.groupby('c')['v'].mean(); st=tmp.groupby('c')['v'].std()
        med=tmp.groupby('c')['v'].median()
        p10=tmp.groupby('c')['v'].quantile(0.10); p90=tmp.groupby('c')['v'].quantile(0.90)
        gm=float(np.nanmean(yv)); gs=float(np.nanstd(yv))
        for labs_arr,out_d in [(trl,tr_out),(tel,te_out)]:
            s=pd.Series(labs_arr)
            out_d[f'c_mean_{nut}']=s.map(mn).fillna(gm).values
            out_d[f'c_std_{nut}']=s.map(st).fillna(gs).values
            out_d[f'c_med_{nut}']=s.map(med).fillna(np.nanmedian(yv)).values
            out_d[f'c_p10_{nut}']=s.map(p10).fillna(np.nanpercentile(yv,10)).values
            out_d[f'c_p90_{nut}']=s.map(p90).fillna(np.nanpercentile(yv,90)).values
    tc_tr=km.cluster_centers_[trl]; tc_te=km.cluster_centers_[tel]
    vc=pd.Series(trl).value_counts()
    tr_out['cluster_size']=pd.Series(trl).map(vc).fillna(1).values.astype(float)
    te_out['cluster_size']=pd.Series(tel).map(vc).fillna(1).values.astype(float)
    tr_out['dist_to_ctr']=np.linalg.norm(train_df[['Latitude','Longitude']].values-tc_tr,axis=1)
    te_out['dist_to_ctr']=np.linalg.norm(test_df[['Latitude','Longitude']].values-tc_te,axis=1)
    # ── RETURN km so we can save it ──────────────────────────────────────────
    return (pd.DataFrame(tr_out).reset_index(drop=True),
            pd.DataFrame(te_out).reset_index(drop=True),
            km)

def coord_features(df):
    lat=df['Latitude'].values; lon=df['Longitude'].values
    out={'lat':lat,'lon':lon,'lat2':lat**2,'lon2':lon**2,'lat_lon':lat*lon,
         'lat3':lat**3,'lon3':lon**3,
         'sin_lat':np.sin(np.radians(lat)),'cos_lat':np.cos(np.radians(lat)),
         'sin_lon':np.sin(np.radians(lon)),'cos_lon':np.cos(np.radians(lon)),
         'sin2_lat':np.sin(np.radians(2*lat)),'cos2_lat':np.cos(np.radians(2*lat)),
         'sin2_lon':np.sin(np.radians(2*lon)),'cos2_lon':np.cos(np.radians(2*lon)),
         'sin3_lat':np.sin(np.radians(3*lat)),'cos3_lat':np.cos(np.radians(3*lat)),
         'abs_lat':np.abs(lat),'is_north':(lat>0).astype(float),
         'is_equatorial':(np.abs(lat)<10).astype(float),
         'is_tropical':(np.abs(lat)<23.5).astype(float),
         'is_s_africa':((lat<-15)&(lon>15)).astype(float),
         'is_sahelian':((lat>10)&(lat<20)).astype(float),
         'is_horn':((lat>-5)&(lat<15)&(lon>35)).astype(float),
         'depth_0_20':(df['Depth_cm']=='0-20').astype(float).values,
         'depth_20_50':(df['Depth_cm']=='20-50').astype(float).values}
    out['climate_zone']=pd.cut(pd.Series(lat),bins=[-90,-23.5,-10,0,10,23.5,90],
                                labels=[0,1,2,3,4,5]).astype(float).fillna(3).values
    for i,(hl,hlo) in enumerate([(-1.3,36.8),(-4.,15.),(9.,7.5),(-29.,26.)]):
        out[f'dist_hs{i}']=haversine_km(lat,lon,np.full_like(lat,hl),np.full_like(lon,hlo))
    return pd.DataFrame(out).reset_index(drop=True)

def direct_features(df, medians=None):
    cols=['C_organic','C_total','ph','horizon_lower','horizon_upper','electrical_conductivity']
    out={}
    for c in cols:
        if c not in df.columns: continue
        v=df[c].values.astype(float)
        med=(medians or {}).get(c,float(np.nanmedian(v)))
        out[c]=np.where(np.isnan(v),med,v)
    if 'horizon_lower' in out and 'horizon_upper' in out:
        out['horizon_thickness']=out['horizon_upper']-out['horizon_lower']
        out['horizon_mid']=(out['horizon_upper']+out['horizon_lower'])/2
    if 'C_organic' in out and 'C_total' in out:
        out['C_org_frac']=out['C_organic']/(out['C_total']+1e-6)
    return pd.DataFrame(out).reset_index(drop=True)

def afsis_priors(geo_df):
    d=geo_df.copy()
    def g(c,default=0.0): return d[c].values.astype(float) if c in d.columns else np.full(len(d),default)
    ph=g('ph',6.5); clay=g('clay_pct',30.); sand=g('sand_pct',40.)
    silt=np.maximum(100.-clay-sand,0.); soc=g('soc',1.); fe_s=g('fe_spectral',1.)
    ndvi=g('ndvi_mean',0.4); evi=g('evi_mean',0.3); prec=g('precip_mean',800.)
    temp=g('temperature',25.); twi=g('twi_real',g('twi_proxy',0.)); elev=g('elevation',500.)
    slope=g('slope',5.); sg_cec=g('sg_cec_0',20.); sg_soc=g('sg_soc_0',1.)
    sg_clay=g('sg_clay_0',30.); sg_n=g('sg_nitrogen_0',0.1); sg_sand=g('sg_sand_0',40.)
    clay_sp=g('clay_spectral',1.); s1_vv=g('s1_vv_mean',-12.); s1_d=g('s1_vv_seasonal_delta',0.)
    water=g('water_occurrence',5.); fire=g('fire_frequency',5.); valley=g('valley_idx',0.)
    laterite=g('laterite_idx',0.5); pet=g('tc_pet_mean',150.); aridity=prec/(pet+1.)
    sal=g('salinity_idx',0.5); n_dry=g('wc_n_dry_months',4.); roughness=g('alos_roughness',10.)
    d['p_Fe_acid']=fe_s*np.exp(np.maximum(5.5-ph,0)*0.8)
    d['p_Fe_redox']=fe_s*(1+s1_d)/(ph-3.5+0.1); d['p_Fe_lat']=laterite*clay/100.
    d['p_Fe_organic']=sg_soc*fe_s*np.exp(-np.maximum(ph-6.5,0))
    d['p_Fe_valley']=valley*fe_s*np.exp(twi/5.); d['p_Fe_season']=s1_d*np.exp(-np.maximum(ph-6.5,0))
    d['p_Fe_weather']=laterite*(1-np.clip(ph/7.,0,1))*clay/100.
    d['p_Al_acid']=np.exp(np.maximum(5.-ph,0)*1.2)*clay/100.
    d['p_Al_weather']=laterite*(1-np.clip(ph/7.,0,1)); d['p_Al_kaol']=clay_sp*np.maximum(1.-ph/6.5,0)
    d['p_Al_gibb']=laterite*np.exp(np.maximum(5.-ph,0)*0.5); d['p_Al_cec']=sg_cec/(sg_cec+clay+1e-6)
    d['p_Al_rain']=prec*laterite/(ph-3.+0.1)
    d['p_Ca_cec']=sg_cec*np.clip(ph/7.,0,1); d['p_Ca_leach']=prec*np.maximum(1.-sg_cec/30.,0)
    d['p_Ca_carb']=np.maximum(ph-7.,0)*sg_cec; d['p_Ca_calcar']=(ph>7.5).astype(float)*sg_cec
    d['p_Ca_aridity']=np.maximum(1.-aridity,0)*sg_cec; d['p_Ca_grass']=evi*(1-np.clip(aridity,0,1))
    d['p_Ca_evap']=n_dry*(sg_cec/(aridity+0.1))
    d['p_Mg_mob']=prec*(1-clay/100.)*np.clip(ph/7.,0.2,1); d['p_Mg_clay']=sg_clay*sg_cec/(aridity+0.1)
    d['p_Mg_leach']=prec*np.maximum(6.-ph,0); d['p_Mg_smect']=sg_clay*np.clip(ph/7.,0,1)*(1-laterite)
    d['p_base_sat']=sg_cec*np.clip((ph-4.5)/3.,0,1)
    d['p_K_clay']=clay*sg_cec/(sand+1e-6); d['p_K_illite']=clay_sp*clay
    d['p_K_leach']=prec*sand/(sg_cec+1e-6); d['p_K_weather']=np.log1p(elev)*clay_sp
    d['p_K_aridity']=np.maximum(1.-aridity,0)*clay/100.
    d['p_N_soc']=sg_soc*sg_n/(sg_soc+1e-6); d['p_N_min']=sg_soc*2.**((temp-25.)/10.)
    d['p_N_veg']=evi*prec/800.; d['p_N_cn']=sg_soc/(sg_n+1e-6); d['p_N_fire']=fire*sg_soc*evi
    d['p_N_leach']=prec*sand/(clay+1e-6)
    d['p_Mn_redox']=(6.5-np.clip(ph,4,8))*np.exp(twi/5.); d['p_Mn_water']=water*(6.5-np.clip(ph,4,8))
    d['p_Mn_season']=s1_d*(6.5-np.clip(ph,4,8)); d['p_Mn_valley']=valley/(ph-3.5+0.1)
    d['p_Mn_organic']=sg_soc*np.maximum(6.-ph,0); d['p_Mn_Fe']=fe_s*(6.5-np.clip(ph,4,8))
    d['p_Mn_conc']=laterite*np.exp(twi/3.)
    d['p_P_fix_acid']=fe_s*np.maximum(6.-ph,0)**1.5; d['p_P_fix_alk']=sg_cec*np.maximum(ph-7.,0)
    d['p_P_avail']=np.exp(-((ph-6.2)**2)/0.8); d['p_P_organic']=sg_soc*ndvi
    d['p_P_erode']=slope*prec*(1-ndvi); d['p_P_alfe']=(fe_s+laterite)*np.maximum(6.-ph,0)
    d['p_S_soc']=sg_soc*clay/(sand+1e-6); d['p_S_fe']=fe_s*np.maximum(6.-ph,0)
    d['p_S_leach']=prec*sand/(sg_cec+1e-6); d['p_S_fire']=fire*ndvi; d['p_S_volc']=roughness*elev/1000.
    d['p_Zn_ph']=np.exp(-np.maximum(ph-6.5,0)*0.9); d['p_Zn_fe']=fe_s*np.exp(-np.maximum(ph-6.5,0)*0.5)
    d['p_Zn_soc']=sg_soc*np.exp(-np.maximum(ph-6.5,0)*0.3); d['p_Zn_clay']=clay*np.exp(-np.maximum(ph-6.5,0)*0.4)
    d['p_Zn_calcar']=sg_cec*np.maximum(ph-7.,0)
    d['p_B_leach']=prec*sand/(clay+1e-6); d['p_B_clay']=clay*np.clip(ph/7.,0.3,1)
    d['p_B_fire']=fire*(1-clay/100.); d['p_B_soc']=sg_soc*clay/100.; d['p_B_dry']=n_dry*(1-clay/100.)
    d['p_Na_evap']=np.maximum(1.-aridity,0)**2; d['p_Na_dry']=n_dry*(1./(aridity+0.1))
    d['p_Na_sal']=sal*np.maximum(1.-aridity,0); d['p_Na_alk']=(ph>8.).astype(float)*sg_cec
    d['p_Cu_som']=sg_soc*np.exp(-np.maximum(ph-7.,0)*0.5); d['p_Cu_acid']=(ph<6.).astype(float)*fe_s
    d['p_Cu_fe']=fe_s*np.clip(ph/7.,0.3,1); d['p_Cu_volc']=roughness*np.exp(-np.maximum(ph-6.5,0))
    d['p_FeAl']=fe_s/(laterite+1e-6); d['p_NP']=sg_n/(np.log1p(fe_s)+1e-6)
    d['p_NPK']=sg_n*sg_soc*sg_cec; d['p_clay_act']=sg_cec/(sg_clay+1e-6)
    d['p_texture']=clay/(sand+silt+1e-6); d['p_aridity_cec']=aridity*sg_cec
    d['p_prec_clay']=prec*clay/100.; d['p_prec_sand']=prec*sand/100.
    d['p_MnFe']=fe_s*(6.5-np.clip(ph,4,8))*np.exp(twi/5.)
    d['p_ZnFe']=fe_s*np.exp(-np.maximum(ph-6.5,0)); d['p_moisture_fe']=water*fe_s
    d['p_fire_n']=fire*sg_n; d['p_temp_soc']=temp*sg_soc; d['p_org_min']=sg_soc/(clay+1e-6)
    def gw(c): return d[c].values.astype(float) if c in d.columns else np.zeros(len(d))
    pa=gw('wc_precip_annual'); pm=gw('tc_pet_mean')
    d['wc_aridity']=pa/(pm+1.); d['wc_wet_dry']=gw('wc_precip_wet_month')-gw('wc_precip_dry_month')
    d['wc_moisture']=(pa-pm)/(pa+pm+1.); d['wc_thwaite']=(pa-pm)/(pm+1.)
    d['koppen_trop']=(gw('wc_temp_annual_mean')>18).astype(float)
    d['koppen_arid']=(pa<pm*0.5).astype(float)
    d['koppen_sav']=((gw('wc_temp_annual_mean')>18)&(pa>300)&(pa<1200)).astype(float)
    new=[c for c in d.columns if c.startswith('p_') or
         c in ['wc_aridity','wc_wet_dry','wc_moisture','wc_thwaite','koppen_trop','koppen_arid','koppen_sav']]
    print(f"  Soil/climate priors: {len(new)} features")
    return d

def feature_screen(X, y, top_n=250):
    m=lgb.LGBMRegressor(n_estimators=300,learning_rate=0.05,max_depth=6,
                          num_leaves=63,subsample=0.8,colsample_bytree=0.7,
                          random_state=42,verbose=-1,n_jobs=-1)
    m.fit(X,y)
    return np.sort(np.argsort(m.feature_importances_)[::-1][:top_n])

def conservative_lookup(train_df, test_df, y_lookup):
    tr_rad=np.radians(train_df[['Latitude','Longitude']].values)
    te_rad=np.radians(test_df[['Latitude','Longitude']].values)
    k=min(100,len(train_df)-1)
    nn=NearestNeighbors(n_neighbors=k,metric='haversine').fit(tr_rad)
    d,ix=nn.kneighbors(te_rad); d_m=d*6371*1000
    n_te=len(test_df); n_nut=len(TARGET_COLS)
    result=np.full((n_te,n_nut),np.nan); tiers=np.full(n_te,4,dtype=int); alphas=np.zeros(n_te)
    for i in range(n_te):
        di=d_m[i]; xi=ix[i]
        if di[0]<1.0:   result[i]=y_lookup[xi[0]]; tiers[i]=0; alphas[i]=1.0
        elif di[0]<50.: mk=di<50.; w=1./(di[mk]**3+1e-8); w/=w.sum(); result[i]=np.einsum('j,jk->k',w,y_lookup[xi[mk]]); tiers[i]=1; alphas[i]=1.0
        elif di[0]<200.:mk=di<200.;w=1./(di[mk]**2+1e-8); w/=w.sum(); result[i]=np.einsum('j,jk->k',w,y_lookup[xi[mk]]); tiers[i]=2; alphas[i]=0.90
        elif di[0]<1000.:mk=di<1000.;w=1./(di[mk]**1.5+1e-8);w/=w.sum();result[i]=np.einsum('j,jk->k',w,y_lookup[xi[mk]]);tiers[i]=3;alphas[i]=0.75
    tc={t:(tiers==t).sum() for t in range(5)}
    print(f"  Lookup tiers: exact={tc[0]} <50m={tc[1]} <200m={tc[2]} <1km={tc[3]} model={tc[4]}")
    return result, tiers, alphas

# ─────────────────────────────────────────────────────────────────────────────
# HYPERPARAMETERS
# ─────────────────────────────────────────────────────────────────────────────
def lgb_params(nut):
    base=dict(learning_rate=0.005,max_depth=10,num_leaves=255,subsample=0.75,
              colsample_bytree=0.65,reg_alpha=0.08,reg_lambda=0.4,min_child_samples=15,
              random_state=42,n_jobs=-1,verbose=-1,min_split_gain=0.01)
    ov={'Al':dict(n_estimators=8000,num_leaves=255,max_depth=10,min_child_samples=15),
        'B': dict(n_estimators=5000,num_leaves=95, max_depth=7, min_child_samples=8,  reg_alpha=0.1,reg_lambda=0.4,subsample=0.78),
        'Ca':dict(n_estimators=10000,num_leaves=191,max_depth=9,min_child_samples=30, reg_alpha=0.2,reg_lambda=1.2,subsample=0.68,colsample_bytree=0.52),
        'Cu':dict(n_estimators=5000,num_leaves=127,max_depth=8, min_child_samples=20),
        'Fe':dict(n_estimators=8000,num_leaves=255,max_depth=10,min_child_samples=15, reg_alpha=0.02,reg_lambda=0.1),
        'K': dict(n_estimators=9000,num_leaves=255,max_depth=10,min_child_samples=18, reg_alpha=0.08,reg_lambda=0.5,subsample=0.72,colsample_bytree=0.60),
        'Mg':dict(n_estimators=8000,num_leaves=191,max_depth=9, min_child_samples=18, reg_alpha=0.10,reg_lambda=0.5,subsample=0.72),
        'Mn':dict(n_estimators=8000,num_leaves=255,max_depth=10,min_child_samples=12, reg_alpha=0.02,reg_lambda=0.1,subsample=0.80),
        'N': dict(n_estimators=8000,num_leaves=191,max_depth=9, min_child_samples=18, reg_alpha=0.04,reg_lambda=0.15,subsample=0.80),
        'Na':dict(n_estimators=6000,num_leaves=127,max_depth=8, min_child_samples=10, reg_alpha=0.15,reg_lambda=0.6,subsample=0.72,colsample_bytree=0.55),
        'P': dict(n_estimators=6000,num_leaves=191,max_depth=9, min_child_samples=10, reg_alpha=0.06,reg_lambda=0.2,subsample=0.75),
        'S': dict(n_estimators=6000,num_leaves=127,max_depth=8, min_child_samples=8,  reg_alpha=0.04,reg_lambda=0.15,subsample=0.80),
        'Zn':dict(n_estimators=5000,num_leaves=95, max_depth=7, min_child_samples=8,  reg_alpha=0.05,reg_lambda=0.2,subsample=0.80)}
    return {**base,**ov.get(nut,{})}

def xgb_params(nut):
    base=dict(learning_rate=0.005,max_depth=8,min_child_weight=10,subsample=0.78,
              colsample_bytree=0.52,reg_alpha=0.5,reg_lambda=0.2,gamma=0.08,
              tree_method='hist',random_state=42,n_jobs=-1)
    ov={'Al':dict(n_estimators=8000,max_depth=8,min_child_weight=8),
        'B': dict(n_estimators=5000,max_depth=5,min_child_weight=5,  reg_alpha=0.3,reg_lambda=0.15,gamma=0.08),
        'Ca':dict(n_estimators=10000,max_depth=7,min_child_weight=18,reg_alpha=1.0,reg_lambda=0.4,gamma=0.20,subsample=0.72),
        'Cu':dict(n_estimators=5000,max_depth=6,min_child_weight=12),
        'Fe':dict(n_estimators=8000,max_depth=8,min_child_weight=8,  reg_alpha=0.1,reg_lambda=0.05,gamma=0.02),
        'K': dict(n_estimators=9000,max_depth=8,min_child_weight=10, reg_alpha=0.5,reg_lambda=0.15,gamma=0.08),
        'Mg':dict(n_estimators=8000,max_depth=7,min_child_weight=10, reg_alpha=0.5,reg_lambda=0.2,gamma=0.10),
        'Mn':dict(n_estimators=8000,max_depth=8,min_child_weight=6,  reg_alpha=0.1,reg_lambda=0.05,gamma=0.02),
        'N': dict(n_estimators=8000,max_depth=7,min_child_weight=10, reg_alpha=0.15,reg_lambda=0.1,gamma=0.04),
        'Na':dict(n_estimators=6000,max_depth=6,min_child_weight=6,  reg_alpha=0.5,reg_lambda=0.25,gamma=0.12),
        'P': dict(n_estimators=6000,max_depth=7,min_child_weight=6,  reg_alpha=0.12,reg_lambda=0.05,gamma=0.02),
        'S': dict(n_estimators=6000,max_depth=6,min_child_weight=5,  reg_alpha=0.15,reg_lambda=0.1,gamma=0.04),
        'Zn':dict(n_estimators=5000,max_depth=5,min_child_weight=5,  reg_alpha=0.2,reg_lambda=0.1,gamma=0.05)}
    return {**base,**ov.get(nut,{})}

def cat_params(nut):
    base=dict(learning_rate=0.005,depth=8,l2_leaf_reg=5.0,random_strength=1.5,
              bagging_temperature=0.7,border_count=128,random_seed=42,thread_count=-1,verbose=0)
    ov={'Al':dict(iterations=6000,depth=8,l2_leaf_reg=4.0),
        'B': dict(iterations=4000,depth=6,l2_leaf_reg=6.0,random_strength=2.0),
        'Ca':dict(iterations=8000,depth=7,l2_leaf_reg=12.0,random_strength=2.5),
        'Cu':dict(iterations=4000,depth=6,l2_leaf_reg=5.0),
        'Fe':dict(iterations=6000,depth=8,l2_leaf_reg=3.0),
        'K': dict(iterations=8000,depth=8,l2_leaf_reg=5.0),
        'Mg':dict(iterations=6000,depth=7,l2_leaf_reg=6.0),
        'Mn':dict(iterations=6000,depth=8,l2_leaf_reg=3.0),
        'N': dict(iterations=6000,depth=7,l2_leaf_reg=4.0),
        'Na':dict(iterations=4000,depth=6,l2_leaf_reg=8.0,random_strength=2.0),
        'P': dict(iterations=4000,depth=7,l2_leaf_reg=4.0),
        'S': dict(iterations=4000,depth=6,l2_leaf_reg=5.0),
        'Zn':dict(iterations=4000,depth=6,l2_leaf_reg=5.0)}
    return {**base,**ov.get(nut,{})}

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":

    Target = pd.read_csv("dataset/TargetPred_To_Keep.csv")
    Train  = pd.read_csv('dataset/Train.csv')
    Test   = pd.read_csv('dataset/TestSet.csv')
    print(f"Train: {Train.shape} | Test: {Test.shape}")

    train_coords = Train[['Latitude','Longitude']].values
    test_coords  = Test[['Latitude','Longitude']].values
    y_train_nan  = Train[TARGET_COLS].values   # keep NaN — CRITICAL

    # mean-filled version for lookup (never use zero-filled for lookup)
    y_means  = np.nanmean(y_train_nan, axis=0)
    y_lookup = np.where(np.isnan(y_train_nan), y_means[np.newaxis,:], y_train_nan)

    def load_csv(tp, ep, label):
        try:
            tr=pd.read_csv(tp); te=pd.read_csv(ep)
            print(f"  ✅ {label}: {tr.shape} / {te.shape}"); return tr,te
        except:
            print(f"  ⚠️  {label} missing"); return pd.DataFrame(),pd.DataFrame()

    print(f"\n{SEP}\nLoading Satellite CSVs\n{SEP}")
    Train_ee,   Test_ee   = load_csv('Train_ee.csv',        'Test_ee.csv',        'GEE')
    Train_sg,   Test_sg   = load_csv('Train_sg.csv',        'Test_sg.csv',        'SoilGrids')
    Train_wc,   Test_wc   = load_csv('Train_worldclim.csv', 'Test_worldclim.csv', 'WorldClim')
    Train_twi,  Test_twi  = load_csv('Train_twi.csv',       'Test_twi.csv',       'TWI')
    Train_sar,  Test_sar  = load_csv('Train_sar.csv',        'Test_sar.csv',       'SAR')
    Train_soil, Test_soil = load_csv('Train_soil_constraints.csv',
                                      'Test_soil_constraints.csv','SOIL')

    # ── Spatial diagnostics ───────────────────────────────────────────────────
    print(f"\n{SEP}\nSpatial Diagnostics\n{SEP}")
    dist_tr_km, dist_te_km = nn_distances_km(train_coords, test_coords)
    for lbl,lo,hi in [('NEAR',0,30),('TRANSITION',30,90),('FAR',90,150),('OOD',150,99999)]:
        n=((dist_te_km>=lo)&(dist_te_km<hi)).sum()
        print(f"  {lbl:12s}: {n:5d} pts ({100*n/len(dist_te_km):.1f}%)")

    # ── Feature Engineering ───────────────────────────────────────────────────
    print(f"\n{SEP}\nFeature Engineering\n{SEP}")
    geo_parts_tr=[coord_features(Train)]; geo_parts_te=[coord_features(Test)]
    for a,b in [(Train_ee,Test_ee),(Train_sg,Test_sg),(Train_wc,Test_wc),
                 (Train_twi,Test_twi),(Train_sar,Test_sar),(Train_soil,Test_soil)]:
        if not a.empty:
            geo_parts_tr.append(a.reset_index(drop=True))
            geo_parts_te.append(b.reset_index(drop=True))
    geo_tr=pd.concat(geo_parts_tr,axis=1); geo_te=pd.concat(geo_parts_te,axis=1)
    geo_tr=geo_tr.loc[:,~geo_tr.columns.duplicated()]
    geo_te=geo_te.loc[:,~geo_te.columns.duplicated()]
    print("  Applying AfSIS soil priors...")
    geo_tr=afsis_priors(geo_tr); geo_te=afsis_priors(geo_te)

    dir_tr=direct_features(Train)
    dir_meds={c:float(dir_tr[c].median()) for c in dir_tr.columns}
    dir_te=direct_features(Test,dir_meds)
    for c in dir_tr.columns:
        if c not in dir_te.columns: dir_te[c]=dir_meds.get(c,0.)

    print(f"\n{SEP}\nSpatial Features\n{SEP}")
    y_for_idw=np.nan_to_num(y_train_nan,nan=0.0)
    Train_idw,Test_idw=multi_scale_idw(train_coords,test_coords,y_for_idw,
                                        powers=(1,2,3),ks=(5,15,30,60,100),
                                        decay_scales=(20,50,150))
    print(f"  IDW features: {Train_idw.shape[1]}")
    Train_dep,Test_dep=depth_stratified_idw(Train,Test,y_for_idw,k=15,power=2)

    # ── cluster_stats_features NOW returns km too ─────────────────────────────
    print("  Computing cluster statistics...")
    Train_clust,Test_clust,km_clust=cluster_stats_features(Train,Test,y_train_nan,n_clusters=150)

    print(f"\n{SEP}\nDepth Pair Features\n{SEP}")
    Train_pair,Test_pair=build_depth_pair_features(Train,Test,y_train_nan)

    spat_tr=pd.DataFrame({'dist_nn_km':dist_tr_km,'log_dist':np.log1p(dist_tr_km),
        'sqrt_dist':np.sqrt(dist_tr_km),'rel_20':np.exp(-dist_tr_km/20.),
        'rel_50':np.exp(-dist_tr_km/50.),'rel_100':np.exp(-dist_tr_km/100.),
        'is_exact':(dist_tr_km<0.1).astype(float),'is_near':(dist_tr_km<30.).astype(float),
        'is_far':(dist_tr_km>50.).astype(float),'is_ood':(dist_tr_km>100.).astype(float)})
    spat_te=pd.DataFrame({'dist_nn_km':dist_te_km,'log_dist':np.log1p(dist_te_km),
        'sqrt_dist':np.sqrt(dist_te_km),'rel_20':np.exp(-dist_te_km/20.),
        'rel_50':np.exp(-dist_te_km/50.),'rel_100':np.exp(-dist_te_km/100.),
        'is_exact':(dist_te_km<0.1).astype(float),'is_near':(dist_te_km<30.).astype(float),
        'is_far':(dist_te_km>50.).astype(float),'is_ood':(dist_te_km>100.).astype(float)})

    print(f"\n{SEP}\nAssembling Base Feature Matrix\n{SEP}")
    all_tr=[geo_tr,Train_idw,Train_dep,Train_clust,Train_pair,dir_tr,spat_tr]
    all_te=[geo_te,Test_idw, Test_dep, Test_clust, Test_pair, dir_te,spat_te]
    Xtr_df=pd.concat([p.reset_index(drop=True) for p in all_tr],axis=1)
    Xte_df=pd.concat([p.reset_index(drop=True) for p in all_te],axis=1)
    Xtr_df=Xtr_df.loc[:,~Xtr_df.columns.duplicated()]
    Xte_df=Xte_df.loc[:,~Xte_df.columns.duplicated()]
    common=sorted(set(Xtr_df.select_dtypes(include=[np.number]).columns)&
                   set(Xte_df.select_dtypes(include=[np.number]).columns))
    for c in common:
        med=float(Xtr_df[c].median())
        Xtr_df[c]=Xtr_df[c].fillna(med); Xte_df[c]=Xte_df[c].fillna(med)
    Xtr_df=Xtr_df[common]; Xte_df=Xte_df[common]
    print(f"  Base features: {len(common)}")

    scaler_base=RobustScaler()
    X_base_tr=scaler_base.fit_transform(Xtr_df)
    X_base_te=scaler_base.transform(Xte_df)

    print(f"\n{SEP}\nCV Groups\n{SEP}")
    km_std=KMeans(n_clusters=60,random_state=42,n_init=10)
    cv_groups=km_std.fit_predict(train_coords)
    nn_ctr=NearestNeighbors(n_neighbors=1,metric='haversine')
    nn_ctr.fit(np.radians(km_std.cluster_centers_))
    d_ctr,_=nn_ctr.kneighbors(np.radians(train_coords))
    d_ctr_km=d_ctr.ravel()*6371
    iso_mask=d_ctr_km>=np.percentile(d_ctr_km,75)
    km_isl=KMeans(n_clusters=18,random_state=42,n_init=10)
    cv_groups[iso_mask]=km_isl.fit_predict(train_coords[iso_mask])+60
    print(f"  CV groups: {len(np.unique(cv_groups))}")

    # ── GEOCHEMICAL CHAINING — trains AND saves chain models in one pass ──────
    print(f"\n{SEP}\nGeochemical Chaining\n{SEP}")

    fast_p=dict(n_estimators=800,learning_rate=0.04,max_depth=7,num_leaves=95,
                subsample=0.8,colsample_bytree=0.7,reg_alpha=0.1,reg_lambda=0.3,
                min_child_samples=15,random_state=42,n_jobs=-1,verbose=-1)

    gkf_chain=GroupKFold(n_splits=5)
    chain_tr=pd.DataFrame(index=range(len(Train)))
    chain_te=pd.DataFrame(index=range(len(Test)))
    chain_full_models={}   # ← collected here, saved immediately after each nut

    for step,nut in enumerate(CHAIN_ORDER):
        if nut not in Train.columns: continue
        y_raw=Train[nut].values; valid=~np.isnan(y_raw)
        y_v=y_raw[valid]; y_log=safe_log1p(y_v); grps_v=cv_groups[valid]
        cc=list(chain_tr.columns)
        Xtr_a=np.hstack([X_base_tr,chain_tr[cc].fillna(0).values]) if cc else X_base_tr
        Xte_a=np.hstack([X_base_te,chain_te[cc].fillna(0).values]) if cc else X_base_te
        Xv=Xtr_a[valid]
        oof=np.zeros(len(Train))
        folds=list(gkf_chain.split(Xv,groups=grps_v))
        ftr,fva=folds[0]
        m=lgb.LGBMRegressor(**fast_p)
        m.fit(Xv[ftr],y_log[ftr],eval_set=[(Xv[fva],y_log[fva])],
              callbacks=[lgb.early_stopping(50,verbose=False),lgb.log_evaluation(-1)])
        oof[np.where(valid)[0][fva]]=safe_expm1(m.predict(Xv[fva]))
        oof[np.where(valid)[0][ftr]]=y_v[ftr]
        oof[~valid]=float(np.nanmean(y_raw))

        # ── train full model on ALL valid rows and SAVE immediately ──────────
        m_full=lgb.LGBMRegressor(**fast_p)
        m_full.fit(Xv,y_log)
        chain_full_models[nut]=m_full
        with open(SAVE_DIR/'chain_models'/f'{nut}.pkl','wb') as f:
            pickle.dump(m_full,f)

        chain_tr[f'chain_{nut}']=oof
        chain_te[f'chain_{nut}']=safe_expm1(m_full.predict(Xte_a))
        val_rmse=rmse(y_v[fva],safe_expm1(m.predict(Xv[fva])))
        print(f"  [{step+1:02d}/{len(CHAIN_ORDER)}] {nut:3s}  val_RMSE={val_rmse:.4f}  ✅ saved")

    for p1,p2 in CHAIN_PAIRS:
        c1,c2=f'chain_{p1}',f'chain_{p2}'
        if c1 in chain_tr.columns and c2 in chain_tr.columns:
            chain_tr[f'cr_{p1}_{p2}']=chain_tr[c1]/(chain_tr[c2].abs()+1e-6)
            chain_te[f'cr_{p1}_{p2}']=chain_te[c1]/(chain_te[c2].abs()+1e-6)
            chain_tr[f'cp_{p1}_{p2}']=chain_tr[c1]*chain_tr[c2]
            chain_te[f'cp_{p1}_{p2}']=chain_te[c1]*chain_te[c2]
            chain_tr[f'cs_{p1}_{p2}']=chain_tr[c1]+chain_tr[c2]
            chain_te[f'cs_{p1}_{p2}']=chain_te[c1]+chain_te[c2]

    print(f"  Chain features: {chain_tr.shape[1]}  |  chain models saved: {len(chain_full_models)}")

    # ── Final feature matrix ──────────────────────────────────────────────────
    Xf_tr=pd.concat([Xtr_df.reset_index(drop=True),chain_tr.reset_index(drop=True)],axis=1)
    Xf_te=pd.concat([Xte_df.reset_index(drop=True),chain_te.reset_index(drop=True)],axis=1)
    Xf_tr=Xf_tr.loc[:,~Xf_tr.columns.duplicated()]
    Xf_te=Xf_te.loc[:,~Xf_te.columns.duplicated()]
    common2=sorted(set(Xf_tr.select_dtypes(include=[np.number]).columns)&
                    set(Xf_te.select_dtypes(include=[np.number]).columns))
    for c in common2:
        med=float(Xf_tr[c].median())
        Xf_tr[c]=Xf_tr[c].fillna(med); Xf_te[c]=Xf_te[c].fillna(med)
    Xf_tr=Xf_tr[common2]; Xf_te=Xf_te[common2]
    scaler_full=RobustScaler()
    X_train=scaler_full.fit_transform(Xf_tr)
    X_test =scaler_full.transform(Xf_te)
    print(f"\n  Final features: {X_train.shape[1]}")

    # ── Save scalers, spatial, and metadata NOW (before the long training loop)
    print(f"\n{SEP}\nSaving Scalers + Spatial Objects\n{SEP}")

    with open(SAVE_DIR/'scalers'/'scaler_base.pkl','wb') as f: pickle.dump(scaler_base,f)
    with open(SAVE_DIR/'scalers'/'scaler_full.pkl','wb') as f: pickle.dump(scaler_full,f)
    print("  ✅ Scalers saved")

    with open(SAVE_DIR/'spatial'/'kmeans_cv.pkl','wb') as f:      pickle.dump(km_std,f)
    with open(SAVE_DIR/'spatial'/'kmeans_cluster.pkl','wb') as f: pickle.dump(km_clust,f)

    train_snapshot={
        'train_coords': Train[['Latitude','Longitude']].values,
        'train_depth':  Train['Depth_cm'].values,
        'train_id':     Train['ID'].values,
        'y_train_nan':  y_train_nan,
    }
    for col in ['C_organic','C_total','ph','horizon_lower','horizon_upper','electrical_conductivity']:
        if col in Train.columns: train_snapshot[f'train_{col}']=Train[col].values
    with open(SAVE_DIR/'spatial'/'train_snapshot.pkl','wb') as f: pickle.dump(train_snapshot,f)
    print("  ✅ Spatial objects + train snapshot saved")

    with open(SAVE_DIR/'direct_medians.json','w') as f: json.dump(dir_meds,f,indent=2)

    meta={'common_cols':common,'common_cols2':common2}
    with open(SAVE_DIR/'meta.json','w') as f: json.dump(meta,f,indent=2)

    chain_meta={'n_base_features':X_base_tr.shape[1],
                'chain_order':CHAIN_ORDER,'chain_pairs':CHAIN_PAIRS}
    with open(SAVE_DIR/'chain_meta.json','w') as f: json.dump(chain_meta,f,indent=2)
    print("  ✅ Metadata saved")

    # ── PER-NUTRIENT ENSEMBLE — trains AND saves each fold model immediately ──
    print(f"\n{SEP}\nTraining Ensemble (LGB + XGB + CAT) — saves each fold immediately\n{SEP}")

    gkf=GroupKFold(n_splits=N_FOLDS)
    final_preds=np.zeros((len(Test),len(TARGET_COLS)))
    oof_preds  =np.zeros((len(Train),len(TARGET_COLS)))
    summary_rows=[]

    for ci,nut in enumerate(TARGET_COLS):
        y_raw=Train[nut].values; valid=~np.isnan(y_raw)
        y_v=y_raw[valid]; y_log=safe_log1p(y_v); grps_v=cv_groups[valid]
        is_sp=nut in SPARSE_NUTS; n_v=valid.sum()

        print(f"\n  ══ [{ci+1:02d}/13] {nut:3s} {'SPARSE' if is_sp else 'DENSE '} n={n_v} ══")

        Xv=X_train[valid]; top_n=180 if is_sp else 250
        fi=feature_screen(Xv,y_log,top_n)
        Xv_fi=Xv[:,fi]; Xte_fi=X_test[:,fi]
        print(f"     Screened to {len(fi)} features")

        # ── Create save dir for this nutrient ────────────────────────────────
        nut_dir=SAVE_DIR/'nutrient_models'/nut
        os.makedirs(nut_dir,exist_ok=True)
        np.save(nut_dir/'feature_idx.npy',fi)   # save feature index immediately

        oof_lgb_v=np.zeros(n_v); oof_xgb_v=np.zeros(n_v); oof_cat_v=np.zeros(n_v)
        te_lgb_folds=np.zeros((N_FOLDS,len(Test)))
        te_xgb_folds=np.zeros((N_FOLDS,len(Test)))
        te_cat_folds=np.zeros((N_FOLDS,len(Test)))

        for fold_i,(ftr,fva) in enumerate(gkf.split(Xv_fi,groups=grps_v)):
            Xf_tr2=Xv_fi[ftr]; yf_tr=y_log[ftr]
            Xf_va =Xv_fi[fva]; yf_va=y_log[fva]
            n_es=max(int(len(ftr)*0.15),30)
            rng=np.random.RandomState(fold_i*17+ci)
            es_vi=rng.choice(len(ftr),n_es,replace=False)
            es_ti=np.setdiff1d(np.arange(len(ftr)),es_vi)

            fold_dir=nut_dir/f'fold_{fold_i}'
            os.makedirs(fold_dir,exist_ok=True)

            # LightGBM
            p=lgb_params(nut)
            ml=lgb.LGBMRegressor(**{**p,'n_estimators':p.get('n_estimators',8000)*2})
            ml.fit(Xf_tr2[es_ti],yf_tr[es_ti],eval_set=[(Xf_tr2[es_vi],yf_tr[es_vi])],
                   callbacks=[lgb.early_stopping(ES_ROUNDS,verbose=False),lgb.log_evaluation(-1)])
            bn_l=ml.best_iteration_
            ml2=lgb.LGBMRegressor(**{**p,'n_estimators':max(bn_l,50)})
            ml2.fit(Xf_tr2,yf_tr)
            oof_lgb_v[fva]=safe_expm1(ml2.predict(Xf_va))
            te_lgb_folds[fold_i]=safe_expm1(ml2.predict(Xte_fi))
            with open(fold_dir/'lgb.pkl','wb') as f: pickle.dump(ml2,f)   # ← save NOW

            # XGBoost
            px=xgb_params(nut)
            mx=xgb.XGBRegressor(**{**px,'n_estimators':px.get('n_estimators',8000)*2,
                                    'early_stopping_rounds':ES_ROUNDS,'eval_metric':'rmse'})
            mx.fit(Xf_tr2[es_ti],yf_tr[es_ti],eval_set=[(Xf_tr2[es_vi],yf_tr[es_vi])],verbose=False)
            bn_x=mx.best_iteration
            mx2=xgb.XGBRegressor(**{**px,'n_estimators':max(bn_x,50)})
            mx2.fit(Xf_tr2,yf_tr)
            oof_xgb_v[fva]=safe_expm1(mx2.predict(Xf_va))
            te_xgb_folds[fold_i]=safe_expm1(mx2.predict(Xte_fi))
            with open(fold_dir/'xgb.pkl','wb') as f: pickle.dump(mx2,f)   # ← save NOW

            # CatBoost
            pc=cat_params(nut)
            mc=cb.CatBoostRegressor(**{**pc,'iterations':pc.get('iterations',5000)*2})
            mc.fit(Xf_tr2[es_ti],yf_tr[es_ti],eval_set=(Xf_tr2[es_vi],yf_tr[es_vi]),
                   early_stopping_rounds=ES_ROUNDS,use_best_model=True,verbose=False)
            bn_c=mc.best_iteration_
            mc2=cb.CatBoostRegressor(**{**pc,'iterations':max(bn_c,50)})
            mc2.fit(Xf_tr2,yf_tr,verbose=False)
            oof_cat_v[fva]=safe_expm1(mc2.predict(Xf_va))
            te_cat_folds[fold_i]=safe_expm1(mc2.predict(Xte_fi))
            with open(fold_dir/'cat.pkl','wb') as f: pickle.dump(mc2,f)   # ← save NOW

            r_l=rmse(y_v[fva],oof_lgb_v[fva])
            r_x=rmse(y_v[fva],oof_xgb_v[fva])
            r_c=rmse(y_v[fva],oof_cat_v[fva])
            print(f"     fold {fold_i+1}: LGB={r_l:.4f} XGB={r_x:.4f} CAT={r_c:.4f} "
                  f"[trees:{bn_l},{bn_x},{bn_c}]  ✅ saved")

        te_lgb=np.clip(te_lgb_folds.mean(0),0,None)
        te_xgb=np.clip(te_xgb_folds.mean(0),0,None)
        te_cat=np.clip(te_cat_folds.mean(0),0,None)
        r_lgb=rmse(y_v,oof_lgb_v); r_xgb=rmse(y_v,oof_xgb_v); r_cat=rmse(y_v,oof_cat_v)

        # Ridge stacking
        oof_s=np.c_[oof_lgb_v,oof_xgb_v,oof_cat_v]
        te_s =np.c_[te_lgb,te_xgb,te_cat]
        try:
            rr=Ridge(alpha=10.,positive=True); rr.fit(oof_s,y_v)
            oof_ridge=np.clip(rr.predict(oof_s),0,None)
            te_ridge =np.clip(rr.predict(te_s), 0,None)
            r_ridge  =rmse(y_v,oof_ridge)
            ridge_coef=rr.coef_; ridge_intercept=float(rr.intercept_)
        except Exception as e:
            print(f"     Ridge failed ({e})")
            r_ridge=min(r_lgb,r_xgb,r_cat)*1.01
            te_ridge=te_cat; oof_ridge=oof_cat_v
            ridge_coef=np.array([0.,0.,1.]); ridge_intercept=0.

        # Nelder-Mead blend
        oof_4=np.c_[oof_lgb_v,oof_xgb_v,oof_cat_v,oof_ridge]
        te_4 =np.c_[te_lgb,te_xgb,te_cat,te_ridge]

        def br(w):
            w=np.clip(w,0,1); w/=(w.sum()+1e-12)
            return rmse(y_v,np.clip(oof_4@w,0,None))

        best_br=np.inf; best_w=None
        inits=[[.25,.25,.25,.25],[.4,.2,.3,.1],[.3,.1,.5,.1],[.1,.1,.7,.1],
               [.2,.2,.2,.4],[.5,.2,.2,.1],[.1,.3,.4,.2],[0.,.1,.6,.3],
               [.4,.1,.1,.4],[.0,.0,.8,.2],[.3,.3,.3,.1]]
        for w0 in inits:
            try:
                res=minimize(br,w0,method='Nelder-Mead',
                             options={'maxiter':3000,'xatol':1e-7,'fatol':1e-9})
                wo=np.clip(res.x,0,1); wo/=wo.sum(); rv=br(wo)
                if rv<best_br: best_br=rv; best_w=wo
            except: pass

        single_best=min(r_lgb,r_xgb,r_cat,r_ridge)
        if best_w is not None and best_br<single_best:
            final_te =np.clip(te_4@best_w,0,None)
            final_oof=np.clip(oof_4@best_w,0,None)
            strat=f"BLEND [{best_w[0]:.2f}L+{best_w[1]:.2f}X+{best_w[2]:.2f}C+{best_w[3]:.2f}R]"
            fr=best_br; blend_weights=best_w
        else:
            bi=np.argmin([r_lgb,r_xgb,r_cat,r_ridge])
            final_te =te_4[:,bi]; final_oof=oof_4[:,bi]
            strat=f"SINGLE={'LXCR'[bi]}"; fr=single_best
            blend_weights=np.eye(4)[bi]

        oof_preds[valid,ci]=final_oof
        final_preds[:,ci]=final_te

        # ── Save blend weights + ridge for this nutrient ─────────────────────
        np.save(nut_dir/'blend_weights.npy',   blend_weights)
        np.save(nut_dir/'ridge_coef.npy',      ridge_coef)
        np.save(nut_dir/'ridge_intercept.npy', np.array([ridge_intercept]))
        print(f"     → {strat}  |  blend+ridge saved ✅")

        scl=METRICS[nut]['scaling']; wt=METRICS[nut]['weight']
        contrib=max(1-fr/scl,-1)*wt
        print(f"     OOF: LGB={r_lgb:.4f} XGB={r_xgb:.4f} CAT={r_cat:.4f} "
              f"Ridge={r_ridge:.4f} → BEST={fr:.4f}  contrib={contrib:.4f}")
        summary_rows.append({'nut':nut,'lgb':r_lgb,'xgb':r_xgb,'cat':r_cat,
                              'ridge':r_ridge,'final':fr,'contrib':contrib,
                              'strat':strat,'n_valid':n_v})

    # ── Conservative Lookup Override ──────────────────────────────────────────
    print(f"\n{SEP}\nConservative Lookup Override\n{SEP}")
    lookup_preds,lookup_tiers,lookup_alphas=conservative_lookup(Train,Test,y_lookup)
    out_preds=final_preds.copy()
    tier_counts={0:0,1:0,2:0,3:0,4:0}
    for i in range(len(Test)):
        t=lookup_tiers[i]; alpha=lookup_alphas[i]; lp=lookup_preds[i]
        if np.any(np.isnan(lp)): continue
        if t in [0,1]:   out_preds[i]=lp; tier_counts[t]+=1
        elif t in [2,3]: out_preds[i]=alpha*lp+(1-alpha)*out_preds[i]; tier_counts[t]+=1
    print(f"  Tier overrides: {tier_counts}")
    out_preds=np.clip(out_preds,0,None)

    # ── Zero Mask ─────────────────────────────────────────────────────────────
    print(f"\n{SEP}\nApplying Zero Mask\n{SEP}")
    target_mask=Target.set_index('ID'); zero_count=0
    for ci,col in enumerate(TARGET_COLS):
        for ri,tid in enumerate(Test['ID'].values):
            if tid in target_mask.index:
                mv=target_mask.loc[tid,col] if col in target_mask.columns else 1
                if mv==0: out_preds[ri,ci]=0.0; zero_count+=1
    print(f"  Zeroed {zero_count} predictions")
    out_preds=np.clip(out_preds,0,None)

    # ── Submission ────────────────────────────────────────────────────────────
    print(f"\n{SEP}\nBuilding Submission\n{SEP}")
    submission=pd.DataFrame({'ID':Test['ID'].values})
    for ci,col in enumerate(TARGET_COLS):
        submission[f'Target_{col}']=out_preds[:,ci]
    expected_cols=['ID']+[f'Target_{c}' for c in TARGET_COLS]
    assert list(submission.columns)==expected_cols, "Column mismatch!"
    try:
        sample=pd.read_csv('dataset/SampleSubmission.csv')
        assert list(sample.columns)==list(submission.columns)
        assert len(sample)==len(submission)
        print("  ✅ Matches SampleSubmission.csv")
    except Exception as e:
        print(f"  ⚠️  {e}")
    submission.to_csv('submission_trophy.csv',index=False)
    print(f"  ✅ submission_trophy.csv  shape={submission.shape}")

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{SEP}\nFinal OOF Summary\n{SEP}")
    est_score=0.
    print(f"\n  {'Nut':>4} | {'n':>6} | {'LGB':>8} | {'XGB':>8} | {'CAT':>8} | "
          f"{'Ridge':>8} | {'BEST':>8} | {'Contrib':>8}")
    print("  "+"-"*80)
    for row in summary_rows:
        print(f"  {row['nut']:>4} | {row['n_valid']:>6} | {row['lgb']:>8.4f} | "
              f"{row['xgb']:>8.4f} | {row['cat']:>8.4f} | {row['ridge']:>8.4f} | "
              f"{row['final']:>8.4f} | {row['contrib']:>8.4f}  {row['strat']}")
        est_score+=row['contrib']
    print(f"\n  Estimated score: {est_score:.4f}")

    print(f"\n{SEP}\nAll Models Saved\n{SEP}")
    print(f"  saved_model/")
    print(f"  ├── scalers/           scaler_base.pkl  scaler_full.pkl")
    print(f"  ├── spatial/           kmeans_cv.pkl  kmeans_cluster.pkl  train_snapshot.pkl")
    print(f"  ├── chain_models/      Fe.pkl Al.pkl Ca.pkl ... ({len(chain_full_models)} files)")
    print(f"  ├── nutrient_models/   Al/ B/ Ca/ ... ({len(summary_rows)} folders × {N_FOLDS} folds)")
    print(f"  ├── direct_medians.json")
    print(f"  ├── meta.json")
    print(f"  └── chain_meta.json")
    print(f"\n🏆 Done — inference.py is ready to run.")
