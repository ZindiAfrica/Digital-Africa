# inference.py
# ============
# Load saved models and generate predictions on new data.
#
# USAGE:
#     python inference.py
#
# Expects new test data at: dataset/TestSet.csv  (same format as competition)
# Optionally provide satellite CSVs in the same folder as training.
# Outputs: submission_new.csv
# ─────────────────────────────────────────────────────────────────────────────

import pickle, json
import numpy as np
import pandas as pd
import lightgbm as lgb
import xgboost as xgb
import catboost as cb
from pathlib import Path
from sklearn.neighbors import NearestNeighbors
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
SAVE_DIR    = Path('saved_model')
TEST_PATH   = 'dataset/TestSet.csv'
OUTPUT_PATH = 'submission_new.csv'

TARGET_COLS = ['Al','B','Ca','Cu','Fe','K','Mg','Mn','N','Na','P','S','Zn']
CHAIN_ORDER = ['Fe','Al','Ca','N','Cu','Mg','K','Mn','Na','B','S','P','Zn']
CHAIN_PAIRS = [('Fe','Al'),('Ca','Mg'),('Ca','K'),('N','P'),('Fe','Mn'),
               ('K','Mg'),('S','Zn'),('P','Zn'),('N','K'),('Ca','Na'),
               ('Fe','P'),('Al','P'),('Mn','Fe'),('Al','Fe'),('Mg','K')]

# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES  (must match train_and_save.py exactly)
# ─────────────────────────────────────────────────────────────────────────────
def safe_log1p(x):
    return np.log1p(np.clip(np.asarray(x, float), 0, None))

def safe_expm1(x):
    return np.expm1(np.clip(np.asarray(x, float), -10, 20))

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1,lon1,lat2,lon2 = map(np.radians, [lat1,lon1,lat2,lon2])
    dlat=lat2-lat1; dlon=lon2-lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2
    return 2*R*np.arcsin(np.sqrt(np.clip(a,0,1)))

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Load saved artifacts
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 72)
print("Loading saved pipeline...")
print("=" * 72)

with open(SAVE_DIR/'scalers'/'scaler_base.pkl',  'rb') as f: scaler_base = pickle.load(f)
with open(SAVE_DIR/'scalers'/'scaler_full.pkl',  'rb') as f: scaler_full = pickle.load(f)
with open(SAVE_DIR/'spatial'/'kmeans_cv.pkl',    'rb') as f: km_std      = pickle.load(f)
with open(SAVE_DIR/'spatial'/'kmeans_cluster.pkl','rb') as f: km_clust   = pickle.load(f)
with open(SAVE_DIR/'spatial'/'train_snapshot.pkl','rb') as f: snap       = pickle.load(f)
with open(SAVE_DIR/'direct_medians.json')  as f: dir_meds   = json.load(f)
with open(SAVE_DIR/'meta.json')            as f: meta        = json.load(f)
with open(SAVE_DIR/'chain_meta.json')      as f: chain_meta  = json.load(f)

# Chain models — one per nutrient
chain_models = {}
for p in sorted((SAVE_DIR/'chain_models').glob('*.pkl')):
    with open(p,'rb') as f: chain_models[p.stem] = pickle.load(f)
print(f"  ✅ Chain models loaded: {sorted(chain_models.keys())}")

# Nutrient models — lgb/xgb/cat per fold
nutrient_models = {}
for nut_dir in sorted((SAVE_DIR/'nutrient_models').iterdir()):
    if not nut_dir.is_dir(): continue
    nut = nut_dir.name
    nm  = {
        'feature_idx':     np.load(nut_dir/'feature_idx.npy'),
        'blend_weights':   np.load(nut_dir/'blend_weights.npy'),
        'ridge_coef':      np.load(nut_dir/'ridge_coef.npy'),
        'ridge_intercept': float(np.load(nut_dir/'ridge_intercept.npy').ravel()[0]),
        'lgb_models':[], 'xgb_models':[], 'cat_models':[],
    }
    for fold_dir in sorted(nut_dir.glob('fold_*')):
        with open(fold_dir/'lgb.pkl','rb') as f: nm['lgb_models'].append(pickle.load(f))
        with open(fold_dir/'xgb.pkl','rb') as f: nm['xgb_models'].append(pickle.load(f))
        with open(fold_dir/'cat.pkl','rb') as f: nm['cat_models'].append(pickle.load(f))
    nutrient_models[nut] = nm
print(f"  ✅ Nutrient models loaded: {sorted(nutrient_models.keys())}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Load new test data + optional satellite CSVs
# ─────────────────────────────────────────────────────────────────────────────
print(f"\nLoading test data from {TEST_PATH}...")
Test = pd.read_csv(TEST_PATH)
print(f"  Test shape: {Test.shape}")

def try_load(path, label):
    try:
        df=pd.read_csv(path); print(f"  ✅ {label}: {df.shape}"); return df
    except:
        print(f"  ⚠️  {label} not found — skipping"); return pd.DataFrame()

Test_ee   = try_load('NewData_ee.csv',               'GEE')
Test_sg   = try_load('NewData_sg.csv',               'SoilGrids')
Test_wc   = try_load('NewData_worldclim.csv',        'WorldClim')
Test_twi  = try_load('NewData_twi.csv',              'TWI')
Test_sar  = try_load('NewData_sar.csv',              'SAR')
Test_soil = try_load('NewData_soil_constraints.csv', 'SOIL')

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Rebuild features (identical to train_and_save.py)
# ─────────────────────────────────────────────────────────────────────────────
train_coords = snap['train_coords']
y_train_nan  = snap['y_train_nan']
y_for_idw    = np.nan_to_num(y_train_nan, nan=0.0)
test_coords  = Test[['Latitude','Longitude']].values

# Mean-filled lookup array — matches train_and_save.py exactly
y_means  = np.nanmean(y_train_nan, axis=0)
y_lookup = np.where(np.isnan(y_train_nan), y_means[np.newaxis,:], y_train_nan)

# Reconstruct minimal train stub from snapshot
train_stub = pd.DataFrame({
    'Latitude':  snap['train_coords'][:,0],
    'Longitude': snap['train_coords'][:,1],
    'Depth_cm':  snap['train_depth'],
    'ID':        snap['train_id'],
})
for col in ['C_organic','C_total','ph','horizon_lower','horizon_upper','electrical_conductivity']:
    if f'train_{col}' in snap:
        train_stub[col] = snap[f'train_{col}']

print("\nBuilding features...")

# ── Coordinate features ───────────────────────────────────────────────────────
def coord_features(df):
    lat=df['Latitude'].values; lon=df['Longitude'].values
    out={
        'lat':lat,'lon':lon,'lat2':lat**2,'lon2':lon**2,'lat_lon':lat*lon,
        'lat3':lat**3,'lon3':lon**3,
        'sin_lat':np.sin(np.radians(lat)),'cos_lat':np.cos(np.radians(lat)),
        'sin_lon':np.sin(np.radians(lon)),'cos_lon':np.cos(np.radians(lon)),
        'sin2_lat':np.sin(np.radians(2*lat)),'cos2_lat':np.cos(np.radians(2*lat)),
        'sin2_lon':np.sin(np.radians(2*lon)),'cos2_lon':np.cos(np.radians(2*lon)),
        'sin3_lat':np.sin(np.radians(3*lat)),'cos3_lat':np.cos(np.radians(3*lat)),
        'abs_lat':np.abs(lat),'is_north':(lat>0).astype(float),
        'is_equatorial':(np.abs(lat)<10).astype(float),
        'is_tropical':(np.abs(lat)<23.5).astype(float),
        'is_s_africa':((lat<-15)&(lon>15)).astype(float),
        'is_sahelian':((lat>10)&(lat<20)).astype(float),
        'is_horn':((lat>-5)&(lat<15)&(lon>35)).astype(float),
        'depth_0_20':(df['Depth_cm']=='0-20').astype(float).values,
        'depth_20_50':(df['Depth_cm']=='20-50').astype(float).values,
    }
    out['climate_zone']=pd.cut(pd.Series(lat),bins=[-90,-23.5,-10,0,10,23.5,90],
                                labels=[0,1,2,3,4,5]).astype(float).fillna(3).values
    for i,(hl,hlo) in enumerate([(-1.3,36.8),(-4.,15.),(9.,7.5),(-29.,26.)]):
        out[f'dist_hs{i}']=haversine_km(lat,lon,np.full_like(lat,hl),np.full_like(lon,hlo))
    return pd.DataFrame(out).reset_index(drop=True)

# ── Multi-scale IDW (test side only) ─────────────────────────────────────────
def multi_scale_idw_test(tr_coords, te_coords, y_train):
    if y_train.ndim==1: y_train=y_train[:,None]
    n_cols=y_train.shape[1]
    ks=(5,15,30,60,100); powers=(1,2,3); decay_scales=(20,50,150)
    k_max=min(max(ks), len(tr_coords)-1)
    nn=NearestNeighbors(n_neighbors=k_max+1,metric='haversine').fit(np.radians(tr_coords))
    d_rad,idx=nn.kneighbors(np.radians(te_coords))
    d_rad=d_rad[:,:k_max]; idx=idx[:,:k_max]; d_km=d_rad*6371
    out={}
    for k in ks:
        k_use=min(k,d_km.shape[1]); dk=d_km[:,:k_use]; ik=idx[:,:k_use]; yk=y_train[ik]
        for pw in powers:
            w=1./(dk**pw+1e-8); w/=w.sum(axis=1,keepdims=True)+1e-12
            pred=np.einsum('ij,ijk->ik',w,yk)
            for j in range(n_cols): out[f'idw_k{k}_p{pw}_{TARGET_COLS[j]}']=pred[:,j]
    k30=min(30,d_km.shape[1]); d30=d_km[:,:k30]; i30=idx[:,:k30]; y30=y_train[i30]
    for ds in decay_scales:
        dw=np.exp(-d30/ds)/(d30**2+1e-8); dw/=dw.sum(axis=1,keepdims=True)+1e-12
        pred=np.einsum('ij,ijk->ik',dw,y30)
        for j in range(n_cols): out[f'idw_decay{ds}_{TARGET_COLS[j]}']=pred[:,j]
    for j in range(n_cols):
        yj=y30[:,:,j]
        out[f'local_mean_k30_{TARGET_COLS[j]}']=yj.mean(axis=1)
        out[f'local_std_k30_{TARGET_COLS[j]}']=yj.std(axis=1)
        out[f'local_range_k30_{TARGET_COLS[j]}']=yj.max(axis=1)-yj.min(axis=1)
        out[f'local_p25_k30_{TARGET_COLS[j]}']=np.percentile(yj,25,axis=1)
        out[f'local_p75_k30_{TARGET_COLS[j]}']=np.percentile(yj,75,axis=1)
    nn1=d_km[:,0]
    out.update({
        'nn1_km':nn1,'nn5_km':d_km[:,min(4,d_km.shape[1]-1)],
        'nn_mean30_km':d_km[:,:30].mean(axis=1),
        'rel_20km':np.exp(-nn1/20.),'rel_50km':np.exp(-nn1/50.),'rel_100km':np.exp(-nn1/100.),
        'n_within_5km':(d_km<5).sum(axis=1).astype(float),
        'n_within_30km':(d_km<30).sum(axis=1).astype(float),
        'n_within_100km':(d_km<100).sum(axis=1).astype(float),
        'is_exact':(nn1<0.1).astype(float),
        'is_near_30km':(nn1<30).astype(float),
        'is_ood_100km':(nn1>100).astype(float),
    })
    return pd.DataFrame(out).reset_index(drop=True)

# ── Depth-stratified IDW (test side only) ────────────────────────────────────
def depth_idw_test(train_df, test_df, y_filled, k=15, power=2):
    n_nut=len(TARGET_COLS); te_out={}
    tr_dep=train_df['Depth_cm'].values
    for di,depth in enumerate(['0-20','20-50']):
        trm=(tr_dep==depth); tem=(test_df['Depth_cm']==depth).values
        if trm.sum()<k+2 or tem.sum()==0: continue
        tc=train_df.loc[trm,['Latitude','Longitude']].values; yd=y_filled[trm]
        ec=test_df.loc[tem,['Latitude','Longitude']].values
        k_te=min(k,trm.sum())
        nn=NearestNeighbors(n_neighbors=k_te,metric='haversine').fit(np.radians(tc))
        d,i=nn.kneighbors(np.radians(ec)); d_km=d*6371
        w=1./(d_km**power+1e-8); w/=w.sum(axis=1,keepdims=True)
        vals=np.einsum('ij,ijk->ik',w,yd[i])
        for j in range(n_nut):
            if f'dep{di}_{TARGET_COLS[j]}' not in te_out:
                te_out[f'dep{di}_{TARGET_COLS[j]}']=np.zeros(len(test_df))
            te_out[f'dep{di}_{TARGET_COLS[j]}'][tem]=vals[:,j]
        if f'dep{di}_rel' not in te_out: te_out[f'dep{di}_rel']=np.ones(len(test_df))
        te_out[f'dep{di}_rel'][tem]=np.exp(-d_km[:,0]/50.)
    for j in range(n_nut):
        col=TARGET_COLS[j]; k0=f'dep0_{col}'; k1=f'dep1_{col}'
        if k0 in te_out and k1 in te_out:
            v0=np.nan_to_num(te_out[k0]); v1=np.nan_to_num(te_out[k1])
            te_out[f'dep_ratio_{col}']=v0/(v1+1e-6)
            te_out[f'dep_diff_{col}']=v0-v1
    return pd.DataFrame(te_out).fillna(0).reset_index(drop=True)

# ── Depth pair features (test side only) ─────────────────────────────────────
def depth_pair_test(train_df, test_df, y_train_nan):
    tr_lat=train_df['Latitude'].values; tr_lon=train_df['Longitude'].values
    tr_dep=train_df['Depth_cm'].values
    te_lat=test_df['Latitude'].values;  te_lon=test_df['Longitude'].values
    te_dep=test_df['Depth_cm'].values
    tr_key=np.array([f"{round(a,4)}_{round(b,4)}" for a,b in zip(tr_lat,tr_lon)])
    te_key=np.array([f"{round(a,4)}_{round(b,4)}" for a,b in zip(te_lat,te_lon)])
    n_te=len(test_df); n_nut=len(TARGET_COLS)
    loc_dep_idx={(tr_key[i],tr_dep[i]):i for i in range(len(train_df))}
    te_other=np.full((n_te,n_nut),np.nan); te_found=np.zeros(n_te,dtype=bool)
    for i in range(n_te):
        od='20-50' if te_dep[i]=='0-20' else '0-20'
        j=loc_dep_idx.get((te_key[i],od),None)
        if j is not None: te_other[i]=y_train_nan[j]; te_found[i]=True
    missing=~te_found
    if missing.sum()>0:
        miss_coords=np.c_[te_lat,te_lon][missing]; miss_dep=te_dep[missing]
        for depth in ['0-20','20-50']:
            od='20-50' if depth=='0-20' else '0-20'; trm=tr_dep==od
            if trm.sum()<2: continue
            tc=np.c_[tr_lat[trm],tr_lon[trm]]; yv=y_train_nan[trm]
            k_use=min(10,trm.sum()-1)
            nn=NearestNeighbors(n_neighbors=k_use,metric='haversine').fit(np.radians(tc))
            sub=miss_dep==depth
            if sub.sum()==0: continue
            d_,i_=nn.kneighbors(np.radians(miss_coords[sub]))
            d_km=d_*6371; w=1./(d_km**2+1e-8); w/=w.sum(axis=1,keepdims=True)
            gidx=np.where(missing)[0][sub]
            for k_sub,k_global in enumerate(gidx):
                vals=yv[i_[k_sub]]
                for j in range(n_nut):
                    vj=vals[:,j]; vld=~np.isnan(vj)
                    if vld.sum()>0:
                        wj=w[k_sub][vld]; wj/=(wj.sum()+1e-12)
                        te_other[k_global,j]=np.dot(wj,vj[vld])
    y_means=np.nanmean(y_train_nan,axis=0); te_df_out={}
    for j,nut in enumerate(TARGET_COLS):
        te_df_out[f'pair_{nut}']=np.where(np.isnan(te_other[:,j]),y_means[j],te_other[:,j])
        te_df_out[f'pair_log_{nut}']=safe_log1p(te_df_out[f'pair_{nut}'])
    te_df_out['pair_found']=te_found.astype(float)
    te_df_out['is_0_20']=(test_df['Depth_cm']=='0-20').astype(float).values
    print(f"  Depth pairs: {te_found.sum()}/{n_te} matched ({100*te_found.mean():.1f}%)")
    return pd.DataFrame(te_df_out).reset_index(drop=True)

# ── Direct soil features ──────────────────────────────────────────────────────
def direct_features(df, medians):
    cols=['C_organic','C_total','ph','horizon_lower','horizon_upper','electrical_conductivity']
    out={}
    for c in cols:
        if c not in df.columns: continue
        v=df[c].values.astype(float); med=medians.get(c,float(np.nanmedian(v)))
        out[c]=np.where(np.isnan(v),med,v)
    if 'horizon_lower' in out and 'horizon_upper' in out:
        out['horizon_thickness']=out['horizon_upper']-out['horizon_lower']
        out['horizon_mid']=(out['horizon_upper']+out['horizon_lower'])/2
    if 'C_organic' in out and 'C_total' in out:
        out['C_org_frac']=out['C_organic']/(out['C_total']+1e-6)
    return pd.DataFrame(out).reset_index(drop=True)

# ── Cluster stats (uses saved km_clust from training) ────────────────────────
def cluster_stats_test(train_df, test_df, y_train_nan, km_model):
    all_coords=np.vstack([train_df[['Latitude','Longitude']].values,
                           test_df[['Latitude','Longitude']].values])
    labs=km_model.predict(all_coords)          # predict — NOT fit_predict
    trl=labs[:len(train_df)]; tel=labs[len(train_df):]
    te_out={}
    for j,nut in enumerate(TARGET_COLS):
        yv=y_train_nan[:,j]; valid=~np.isnan(yv)
        if valid.sum()<10: continue
        tmp=pd.DataFrame({'c':trl[valid],'v':yv[valid]})
        mn=tmp.groupby('c')['v'].mean(); st=tmp.groupby('c')['v'].std()
        med=tmp.groupby('c')['v'].median()
        p10=tmp.groupby('c')['v'].quantile(0.10); p90=tmp.groupby('c')['v'].quantile(0.90)
        s=pd.Series(tel)
        te_out[f'c_mean_{nut}']=s.map(mn).fillna(float(np.nanmean(yv))).values
        te_out[f'c_std_{nut}']=s.map(st).fillna(float(np.nanstd(yv))).values
        te_out[f'c_med_{nut}']=s.map(med).fillna(float(np.nanmedian(yv))).values
        te_out[f'c_p10_{nut}']=s.map(p10).fillna(float(np.nanpercentile(yv,10))).values
        te_out[f'c_p90_{nut}']=s.map(p90).fillna(float(np.nanpercentile(yv,90))).values
    tc_te=km_model.cluster_centers_[tel]
    vc=pd.Series(trl).value_counts()
    te_out['cluster_size']=pd.Series(tel).map(vc).fillna(1).values.astype(float)
    te_out['dist_to_ctr']=np.linalg.norm(
        test_df[['Latitude','Longitude']].values - tc_te, axis=1)
    return pd.DataFrame(te_out).reset_index(drop=True)

# ── AfSIS priors (identical to train_and_save.py) ────────────────────────────
def afsis_priors(geo_df):
    d=geo_df.copy()
    def g(c,default=0.0): return d[c].values.astype(float) if c in d.columns else np.full(len(d),default)
    ph=g('ph',6.5); clay=g('clay_pct',30.); sand=g('sand_pct',40.)
    silt=np.maximum(100.-clay-sand,0.); soc=g('soc',1.); fe_s=g('fe_spectral',1.)
    ndvi=g('ndvi_mean',0.4); evi=g('evi_mean',0.3); prec=g('precip_mean',800.)
    temp=g('temperature',25.); twi=g('twi_real',g('twi_proxy',0.)); elev=g('elevation',500.)
    slope=g('slope',5.); sg_cec=g('sg_cec_0',20.); sg_soc=g('sg_soc_0',1.)
    sg_clay=g('sg_clay_0',30.); sg_n=g('sg_nitrogen_0',0.1); sg_sand=g('sg_sand_0',40.)
    clay_sp=g('clay_spectral',1.); s1_vv=g('s1_vv_mean',-12.); s1_d=g('s1_vv_seasonal_delta',0.)
    water=g('water_occurrence',5.); fire=g('fire_frequency',5.); valley=g('valley_idx',0.)
    laterite=g('laterite_idx',0.5); pet=g('tc_pet_mean',150.); aridity=prec/(pet+1.)
    sal=g('salinity_idx',0.5); n_dry=g('wc_n_dry_months',4.); roughness=g('alos_roughness',10.)
    priors={
        'p_Fe_acid':fe_s*np.exp(np.maximum(5.5-ph,0)*0.8),
        'p_Fe_redox':fe_s*(1+s1_d)/(ph-3.5+0.1),'p_Fe_lat':laterite*clay/100.,
        'p_Fe_organic':sg_soc*fe_s*np.exp(-np.maximum(ph-6.5,0)),
        'p_Fe_valley':valley*fe_s*np.exp(twi/5.),'p_Fe_season':s1_d*np.exp(-np.maximum(ph-6.5,0)),
        'p_Fe_weather':laterite*(1-np.clip(ph/7.,0,1))*clay/100.,
        'p_Al_acid':np.exp(np.maximum(5.-ph,0)*1.2)*clay/100.,
        'p_Al_weather':laterite*(1-np.clip(ph/7.,0,1)),'p_Al_kaol':clay_sp*np.maximum(1.-ph/6.5,0),
        'p_Al_gibb':laterite*np.exp(np.maximum(5.-ph,0)*0.5),'p_Al_cec':sg_cec/(sg_cec+clay+1e-6),
        'p_Al_rain':prec*laterite/(ph-3.+0.1),
        'p_Ca_cec':sg_cec*np.clip(ph/7.,0,1),'p_Ca_leach':prec*np.maximum(1.-sg_cec/30.,0),
        'p_Ca_carb':np.maximum(ph-7.,0)*sg_cec,'p_Ca_calcar':(ph>7.5).astype(float)*sg_cec,
        'p_Ca_aridity':np.maximum(1.-aridity,0)*sg_cec,'p_Ca_grass':evi*(1-np.clip(aridity,0,1)),
        'p_Ca_evap':n_dry*(sg_cec/(aridity+0.1)),
        'p_Mg_mob':prec*(1-clay/100.)*np.clip(ph/7.,0.2,1),'p_Mg_clay':sg_clay*sg_cec/(aridity+0.1),
        'p_Mg_leach':prec*np.maximum(6.-ph,0),'p_Mg_smect':sg_clay*np.clip(ph/7.,0,1)*(1-laterite),
        'p_base_sat':sg_cec*np.clip((ph-4.5)/3.,0,1),
        'p_K_clay':clay*sg_cec/(sand+1e-6),'p_K_illite':clay_sp*clay,
        'p_K_leach':prec*sand/(sg_cec+1e-6),'p_K_weather':np.log1p(elev)*clay_sp,
        'p_K_aridity':np.maximum(1.-aridity,0)*clay/100.,
        'p_N_soc':sg_soc*sg_n/(sg_soc+1e-6),'p_N_min':sg_soc*2.**((temp-25.)/10.),
        'p_N_veg':evi*prec/800.,'p_N_cn':sg_soc/(sg_n+1e-6),'p_N_fire':fire*sg_soc*evi,
        'p_N_leach':prec*sand/(clay+1e-6),
        'p_Mn_redox':(6.5-np.clip(ph,4,8))*np.exp(twi/5.),'p_Mn_water':water*(6.5-np.clip(ph,4,8)),
        'p_Mn_season':s1_d*(6.5-np.clip(ph,4,8)),'p_Mn_valley':valley/(ph-3.5+0.1),
        'p_Mn_organic':sg_soc*np.maximum(6.-ph,0),'p_Mn_Fe':fe_s*(6.5-np.clip(ph,4,8)),
        'p_Mn_conc':laterite*np.exp(twi/3.),
        'p_P_fix_acid':fe_s*np.maximum(6.-ph,0)**1.5,'p_P_fix_alk':sg_cec*np.maximum(ph-7.,0),
        'p_P_avail':np.exp(-((ph-6.2)**2)/0.8),'p_P_organic':sg_soc*ndvi,
        'p_P_erode':slope*prec*(1-ndvi),'p_P_alfe':(fe_s+laterite)*np.maximum(6.-ph,0),
        'p_S_soc':sg_soc*clay/(sand+1e-6),'p_S_fe':fe_s*np.maximum(6.-ph,0),
        'p_S_leach':prec*sand/(sg_cec+1e-6),'p_S_fire':fire*ndvi,'p_S_volc':roughness*elev/1000.,
        'p_Zn_ph':np.exp(-np.maximum(ph-6.5,0)*0.9),'p_Zn_fe':fe_s*np.exp(-np.maximum(ph-6.5,0)*0.5),
        'p_Zn_soc':sg_soc*np.exp(-np.maximum(ph-6.5,0)*0.3),'p_Zn_clay':clay*np.exp(-np.maximum(ph-6.5,0)*0.4),
        'p_Zn_calcar':sg_cec*np.maximum(ph-7.,0),
        'p_B_leach':prec*sand/(clay+1e-6),'p_B_clay':clay*np.clip(ph/7.,0.3,1),
        'p_B_fire':fire*(1-clay/100.),'p_B_soc':sg_soc*clay/100.,'p_B_dry':n_dry*(1-clay/100.),
        'p_Na_evap':np.maximum(1.-aridity,0)**2,'p_Na_dry':n_dry*(1./(aridity+0.1)),
        'p_Na_sal':sal*np.maximum(1.-aridity,0),'p_Na_alk':(ph>8.).astype(float)*sg_cec,
        'p_Cu_som':sg_soc*np.exp(-np.maximum(ph-7.,0)*0.5),'p_Cu_acid':(ph<6.).astype(float)*fe_s,
        'p_Cu_fe':fe_s*np.clip(ph/7.,0.3,1),'p_Cu_volc':roughness*np.exp(-np.maximum(ph-6.5,0)),
        'p_FeAl':fe_s/(laterite+1e-6),'p_NP':sg_n/(np.log1p(fe_s)+1e-6),
        'p_NPK':sg_n*sg_soc*sg_cec,'p_clay_act':sg_cec/(sg_clay+1e-6),
        'p_texture':clay/(sand+silt+1e-6),'p_aridity_cec':aridity*sg_cec,
        'p_prec_clay':prec*clay/100.,'p_prec_sand':prec*sand/100.,
        'p_MnFe':fe_s*(6.5-np.clip(ph,4,8))*np.exp(twi/5.),
        'p_ZnFe':fe_s*np.exp(-np.maximum(ph-6.5,0)),'p_moisture_fe':water*fe_s,
        'p_fire_n':fire*sg_n,'p_temp_soc':temp*sg_soc,'p_org_min':sg_soc/(clay+1e-6),
    }
    def gw(c): return d[c].values.astype(float) if c in d.columns else np.zeros(len(d))
    pa=gw('wc_precip_annual'); pm=gw('tc_pet_mean')
    priors.update({
        'wc_aridity':pa/(pm+1.),'wc_wet_dry':gw('wc_precip_wet_month')-gw('wc_precip_dry_month'),
        'wc_moisture':(pa-pm)/(pa+pm+1.),'wc_thwaite':(pa-pm)/(pm+1.),
        'koppen_trop':(gw('wc_temp_annual_mean')>18).astype(float),
        'koppen_arid':(pa<pm*0.5).astype(float),
        'koppen_sav':((gw('wc_temp_annual_mean')>18)&(pa>300)&(pa<1200)).astype(float),
    })
    for k,v in priors.items(): d[k]=v
    return d

# ── Assemble geo features ─────────────────────────────────────────────────────
geo_parts=[coord_features(Test)]
for sat_df in [Test_ee,Test_sg,Test_wc,Test_twi,Test_sar,Test_soil]:
    if not sat_df.empty: geo_parts.append(sat_df.reset_index(drop=True))
geo_te=pd.concat(geo_parts,axis=1)
geo_te=geo_te.loc[:,~geo_te.columns.duplicated()]
geo_te=afsis_priors(geo_te)

# ── NN distances ──────────────────────────────────────────────────────────────
nn_tr=NearestNeighbors(n_neighbors=2,metric='haversine').fit(np.radians(train_coords))
d_te,_=nn_tr.kneighbors(np.radians(test_coords))
dist_te_km=d_te[:,0]*6371

# ── All spatial features ──────────────────────────────────────────────────────
print("  IDW features...")
Test_idw   = multi_scale_idw_test(train_coords, test_coords, y_for_idw)
print("  Depth IDW features...")
Test_dep   = depth_idw_test(train_stub, Test, y_for_idw)
print("  Cluster features...")
Test_clust = cluster_stats_test(train_stub, Test, y_train_nan, km_clust)
print("  Depth pair features...")
Test_pair  = depth_pair_test(train_stub, Test, y_train_nan)
print("  Direct soil features...")
dir_te     = direct_features(Test, dir_meds)

spat_te=pd.DataFrame({
    'dist_nn_km':dist_te_km,'log_dist':np.log1p(dist_te_km),'sqrt_dist':np.sqrt(dist_te_km),
    'rel_20':np.exp(-dist_te_km/20.),'rel_50':np.exp(-dist_te_km/50.),'rel_100':np.exp(-dist_te_km/100.),
    'is_exact':(dist_te_km<0.1).astype(float),'is_near':(dist_te_km<30.).astype(float),
    'is_far':(dist_te_km>50.).astype(float),'is_ood':(dist_te_km>100.).astype(float),
})

# ── Base feature matrix ───────────────────────────────────────────────────────
all_te=[geo_te,Test_idw,Test_dep,Test_clust,Test_pair,dir_te,spat_te]
Xte_df=pd.concat([p.reset_index(drop=True) for p in all_te],axis=1)
Xte_df=Xte_df.loc[:,~Xte_df.columns.duplicated()]

common=meta['common_cols']
for c in common:
    if c not in Xte_df.columns: Xte_df[c]=0.0
for c in common:
    med=Xte_df[c].median()
    Xte_df[c]=Xte_df[c].fillna(0.0 if np.isnan(med) else float(med))
Xte_df=Xte_df[common]
X_base_te=scaler_base.transform(Xte_df)
print(f"  Base features: {X_base_te.shape[1]}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Chain features
# Uses the n_base_features from chain_meta to build augmented X correctly
# ─────────────────────────────────────────────────────────────────────────────
print("\nBuilding chain features...")
n_base = chain_meta['n_base_features']   # how many base cols the chain models expect

chain_te=pd.DataFrame(index=range(len(Test)))

for nut in CHAIN_ORDER:
    cm=chain_models.get(nut)
    if cm is None:
        print(f"  ⚠️  No chain model for {nut} — skipping")
        continue
    cc=list(chain_te.columns)
    # Chain models were trained on X_base_tr (n_base cols) + chain cols so far
    if cc:
        Xte_a=np.hstack([X_base_te, chain_te[cc].fillna(0).values])
    else:
        Xte_a=X_base_te
    chain_te[f'chain_{nut}']=safe_expm1(cm.predict(Xte_a))

for p1,p2 in CHAIN_PAIRS:
    c1,c2=f'chain_{p1}',f'chain_{p2}'
    if c1 in chain_te.columns and c2 in chain_te.columns:
        chain_te[f'cr_{p1}_{p2}']=chain_te[c1]/(chain_te[c2].abs()+1e-6)
        chain_te[f'cp_{p1}_{p2}']=chain_te[c1]*chain_te[c2]
        chain_te[f'cs_{p1}_{p2}']=chain_te[c1]+chain_te[c2]

print(f"  Chain features: {chain_te.shape[1]}")

# ── Full feature matrix ───────────────────────────────────────────────────────
Xf_te=pd.concat([Xte_df.reset_index(drop=True),chain_te.reset_index(drop=True)],axis=1)
Xf_te=Xf_te.loc[:,~Xf_te.columns.duplicated()]

common2=meta['common_cols2']
for c in common2:
    if c not in Xf_te.columns: Xf_te[c]=0.0
for c in common2:
    med=Xf_te[c].median()
    Xf_te[c]=Xf_te[c].fillna(0.0 if np.isnan(med) else float(med))
Xf_te=Xf_te[common2]
X_test=scaler_full.transform(Xf_te)
print(f"  Final features: {X_test.shape[1]}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Predict each nutrient
# ─────────────────────────────────────────────────────────────────────────────
print("\nPredicting nutrients...")
final_preds=np.zeros((len(Test),len(TARGET_COLS)))

for ci,nut in enumerate(TARGET_COLS):
    nm=nutrient_models.get(nut)
    if nm is None:
        print(f"  ⚠️  No model for {nut} — filling with training mean")
        final_preds[:,ci]=float(y_means[ci])
        continue

    fi     =nm['feature_idx']
    Xte_fi =X_test[:,fi]
    n_folds=len(nm['lgb_models'])

    te_lgb=np.zeros(len(Test))
    te_xgb=np.zeros(len(Test))
    te_cat=np.zeros(len(Test))

    for k in range(n_folds):
        te_lgb+=safe_expm1(nm['lgb_models'][k].predict(Xte_fi))
        te_xgb+=safe_expm1(nm['xgb_models'][k].predict(Xte_fi))
        te_cat+=safe_expm1(nm['cat_models'][k].predict(Xte_fi))

    te_lgb=np.clip(te_lgb/n_folds,0,None)
    te_xgb=np.clip(te_xgb/n_folds,0,None)
    te_cat=np.clip(te_cat/n_folds,0,None)

    te_s    =np.c_[te_lgb,te_xgb,te_cat]
    te_ridge=np.clip(te_s@nm['ridge_coef']+nm['ridge_intercept'],0,None)

    w   =nm['blend_weights']
    te_4=np.c_[te_lgb,te_xgb,te_cat,te_ridge]
    final_preds[:,ci]=np.clip(te_4@w,0,None)
    print(f"  {nut:3s}: mean={final_preds[:,ci].mean():.4f}  "
          f"max={final_preds[:,ci].max():.4f}  folds={n_folds}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Conservative lookup override (exact / near matches)
# ─────────────────────────────────────────────────────────────────────────────
print("\nApplying conservative lookup override...")
tr_rad=np.radians(train_coords); te_rad=np.radians(test_coords)
k_lu=min(100,len(train_coords)-1)
nn_lu=NearestNeighbors(n_neighbors=k_lu,metric='haversine').fit(tr_rad)
d_lu,ix_lu=nn_lu.kneighbors(te_rad)
d_m=d_lu*6371*1000   # convert to metres

out_preds=final_preds.copy()
tier_counts={0:0,1:0,2:0,3:0}

for i in range(len(Test)):
    di=d_m[i]; xi=ix_lu[i]
    if di[0]<1.0:
        out_preds[i]=y_lookup[xi[0]]; tier_counts[0]+=1
    elif di[0]<50.0:
        mk=di<50.; w=1./(di[mk]**3+1e-8); w/=w.sum()
        out_preds[i]=np.einsum('j,jk->k',w,y_lookup[xi[mk]]); tier_counts[1]+=1
    elif di[0]<200.0:
        mk=di<200.; w=1./(di[mk]**2+1e-8); w/=w.sum()
        out_preds[i]=0.90*np.einsum('j,jk->k',w,y_lookup[xi[mk]])+0.10*out_preds[i]; tier_counts[2]+=1
    elif di[0]<1000.0:
        mk=di<1000.; w=1./(di[mk]**1.5+1e-8); w/=w.sum()
        out_preds[i]=0.75*np.einsum('j,jk->k',w,y_lookup[xi[mk]])+0.25*out_preds[i]; tier_counts[3]+=1

print(f"  Tiers: exact={tier_counts[0]}  <50m={tier_counts[1]}  "
      f"<200m={tier_counts[2]}  <1km={tier_counts[3]}")
out_preds=np.clip(out_preds,0,None)

# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 — Build and save submission
# ─────────────────────────────────────────────────────────────────────────────
submission=pd.DataFrame({'ID':Test['ID'].values})
for ci,col in enumerate(TARGET_COLS):
    submission[f'Target_{col}']=out_preds[:,ci]

expected_cols=['ID']+[f'Target_{c}' for c in TARGET_COLS]
assert list(submission.columns)==expected_cols, \
    f"Column mismatch!\nExpected: {expected_cols}\nGot: {list(submission.columns)}"

submission.to_csv(OUTPUT_PATH,index=False)
print(f"\n✅ Submission saved → {OUTPUT_PATH}  shape={submission.shape}")
print(submission.head())

# ── Prediction stats ──────────────────────────────────────────────────────────
print("\nPrediction stats:")
for ci,col in enumerate(TARGET_COLS):
    v=out_preds[:,ci]; nz=v>0
    print(f"  {col:3s}: min={v[nz].min() if nz.any() else 0:.4f}  "
          f"mean={v[nz].mean() if nz.any() else 0:.4f}  "
          f"max={v.max():.4f}  zeros={(~nz).sum()}")
