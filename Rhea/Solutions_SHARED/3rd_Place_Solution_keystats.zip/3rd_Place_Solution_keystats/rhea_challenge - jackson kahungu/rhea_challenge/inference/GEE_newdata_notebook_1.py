"""
GEE_newdata_notebook_1.py
=========================
NEW DATA EXTRACTION — NOTEBOOK 1 of 2
Run both notebooks simultaneously in separate Colab tabs.

EXTRACTIONS IN THIS NOTEBOOK:
  RUN_GEE        → NewData_ee.csv
  RUN_SOILGRIDS  → NewData_sg.csv
  RUN_WORLDCLIM  → NewData_worldclim.csv
"""

import ee
import pandas as pd
import numpy as np
from tqdm import tqdm
import time
import warnings
warnings.filterwarnings('ignore')

# ── TOGGLE ────────────────────────────────────────────────────────────────────
RUN_GEE       = True
RUN_SOILGRIDS = True
RUN_WORLDCLIM = True

START = '2008-01-01'
END   = '2018-12-31'

# ── INIT ──────────────────────────────────────────────────────────────────────
try:
    ee.Initialize(project='radiant-cycle-429609-g2')
    print("✅ Earth Engine initialized")
except:
    ee.Initialize()

NewData = pd.read_csv('../additional_test_dataset.csv')   # ← your new data file
print(f"NewData: {NewData.shape}")


# ── SHARED EXTRACTOR ──────────────────────────────────────────────────────────
def extract(df, img, batch_size=50, scale=1000, label=""):
    all_rows = []; n = (len(df) + batch_size - 1) // batch_size
    band_names = None; failed = 0
    print(f"\n🛰️  {label}: {len(df)} pts | {n} batches | scale={scale}m")
    for bi in tqdm(range(n), desc=label):
        s = bi * batch_size; e = min(s + batch_size, len(df))
        batch = df.iloc[s:e]; rows = []; ok = False
        for attempt in range(4):
            try:
                fc = ee.FeatureCollection([
                    ee.Feature(ee.Geometry.Point([float(r['Longitude']), float(r['Latitude'])]),
                               {'_i': i})
                    for i, (_, r) in enumerate(batch.iterrows())])
                res = img.reduceRegions(collection=fc, reducer=ee.Reducer.first(),
                          scale=scale).getInfo()['features']
                if band_names is None and res:
                    band_names = [k for k in res[0]['properties'] if k != '_i']
                idx_map = {f['properties']['_i']: {k: v for k, v in f['properties'].items() if k != '_i'}
                           for f in res}
                for i in range(len(batch)):
                    rows.append(idx_map.get(i, {k: np.nan for k in (band_names or [])}))
                ok = True; break
            except Exception as ex:
                if attempt < 3:
                    w = 10 * (attempt + 1)
                    print(f"\n  ⚠️  batch {bi} attempt {attempt+1}: {str(ex)[:80]} — wait {w}s")
                    time.sleep(w)
                else:
                    failed += 1
                    rows = [{k: np.nan for k in (band_names or [])} for _ in range(len(batch))]
        all_rows.extend(rows)
        time.sleep(0.3)
    if not band_names:
        print("  ⚠️  nothing extracted"); return pd.DataFrame()
    df_out = pd.DataFrame(all_rows, columns=band_names)
    print(f"  ✅ {label}: {df_out.shape[1]} bands | {100*df_out.notna().mean().mean():.1f}% non-null | failed={failed}")
    return df_out


def run(tag, build_fn, out_csv, batch_size=50, scale=1000):
    print(f"\n{'='*60}\n{tag}\n{'='*60}")
    try:
        existing = pd.read_csv(out_csv)
        print(f"  ✅ {out_csv} exists — {existing.shape} — skipping"); return
    except:
        pass
    img = build_fn()
    result = extract(NewData, img, batch_size, scale, tag)
    if not result.empty:
        result.to_csv(out_csv, index=False)
        print(f"  💾 {out_csv}")


# ── IMAGE BUILDERS ────────────────────────────────────────────────────────────

def build_gee():
    srtm  = ee.Image('USGS/SRTMGL1_003').select('elevation')
    slope = ee.Terrain.slope(srtm).rename('slope')
    asp   = ee.Terrain.aspect(srtm).rename('aspect')
    twi   = slope.add(0.001).log().multiply(-1).rename('twi_proxy')

    chirps  = ee.ImageCollection('UCSB-CHG/CHIRPS/PENTAD').filterDate(START, END).select('precipitation')
    pr_mean = chirps.mean().rename('precip_mean')
    pr_std  = chirps.reduce(ee.Reducer.stdDev()).rename('precip_std')
    pr_dry  = chirps.filter(ee.Filter.calendarRange(6,  9, 'month')).mean().rename('precip_dry')
    pr_wet  = chirps.filter(ee.Filter.calendarRange(11, 3, 'month')).mean().rename('precip_wet')
    pr_max  = chirps.max().rename('precip_max')

    lst      = ee.ImageCollection('MODIS/061/MOD11A2').filterDate(START, END).select('LST_Day_1km')
    temp     = lst.mean().multiply(0.02).subtract(273.15).rename('temperature')
    temp_std = lst.reduce(ee.Reducer.stdDev()).multiply(0.02).rename('temp_std')
    temp_dry = lst.filter(ee.Filter.calendarRange(6, 9, 'month')).mean().multiply(0.02).subtract(273.15).rename('temp_dry')
    temp_wet = lst.filter(ee.Filter.calendarRange(11,3, 'month')).mean().multiply(0.02).subtract(273.15).rename('temp_wet')

    ndvi      = ee.ImageCollection('MODIS/061/MOD13A2').filterDate(START, END).select('NDVI')
    ndvi_mean = ndvi.mean().multiply(0.0001).rename('ndvi_mean')
    ndvi_std  = ndvi.reduce(ee.Reducer.stdDev()).multiply(0.0001).rename('ndvi_std')
    ndvi_max  = ndvi.max().multiply(0.0001).rename('ndvi_max')
    ndvi_min  = ndvi.min().multiply(0.0001).rename('ndvi_min')
    ndvi_dry  = ndvi.filter(ee.Filter.calendarRange(6,  9, 'month')).mean().multiply(0.0001).rename('ndvi_dry')
    ndvi_wet  = ndvi.filter(ee.Filter.calendarRange(11, 3, 'month')).mean().multiply(0.0001).rename('ndvi_wet')

    evi      = ee.ImageCollection('MODIS/061/MOD13A2').filterDate(START, END).select('EVI')
    evi_mean = evi.mean().multiply(0.0001).rename('evi_mean')
    evi_std  = evi.reduce(ee.Reducer.stdDev()).multiply(0.0001).rename('evi_std')

    s2    = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterDate(START, END)
               .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
               .select(['B2','B3','B4','B8','B11','B12']).median())
    blue  = s2.select('B2'); green = s2.select('B3'); red   = s2.select('B4')
    nir   = s2.select('B8'); swir1 = s2.select('B11'); swir2 = s2.select('B12')
    bsi   = s2.expression('((SWIR1+RED)-(NIR+BLUE))/((SWIR1+RED)+(NIR+BLUE)+1e-4)',
              {'SWIR1':swir1,'RED':red,'NIR':nir,'BLUE':blue}).rename('bsi')
    clay_s = swir1.divide(swir2.add(1e-4)).rename('clay_spectral')
    fe_s   = red.divide(blue.add(1e-4)).rename('fe_spectral')
    color  = red.divide(green.add(1e-4)).rename('coloration')
    ndwi   = green.subtract(nir).divide(green.add(nir).add(1e-4)).rename('ndwi')
    ndwi2  = nir.subtract(swir1).divide(nir.add(swir1).add(1e-4)).rename('ndwi2')
    sal    = red.multiply(nir).sqrt().rename('salinity_idx')
    s2b    = s2.select(['B2','B3','B4','B8','B11','B12']).rename(
               ['s2_blue','s2_green','s2_red','s2_nir','s2_swir1','s2_swir2'])

    clay_pct = ee.Image('OpenLandMap/SOL/SOL_CLAY-WFRACTION_USDA-3A1A1A_M/v02').select('b0').rename('clay_pct')
    sand_pct = ee.Image('OpenLandMap/SOL/SOL_SAND-WFRACTION_USDA-3A1A1A_M/v02').select('b0').rename('sand_pct')
    ph_soil  = ee.Image('OpenLandMap/SOL/SOL_PH-H2O_USDA-4C1A2A_M/v02').select('b0').rename('ph')
    soc      = ee.Image('OpenLandMap/SOL/SOL_ORGANIC-CARBON_USDA-6A1C_M/v02').select('b0').rename('soc')
    lights   = (ee.ImageCollection('NOAA/DMSP-OLS/NIGHTTIME_LIGHTS').filterDate(START, END)
                  .select('stable_lights').mean().rename('nightlights'))

    print("  ✅ GEE 39 bands")
    return ee.Image.cat([
        srtm.select('elevation'), slope, asp, twi,
        pr_mean, pr_std, pr_dry, pr_wet, pr_max,
        temp, temp_std, temp_dry, temp_wet,
        ndvi_mean, ndvi_std, ndvi_max, ndvi_min, ndvi_dry, ndvi_wet,
        evi_mean, evi_std,
        bsi, clay_s, fe_s, color, ndwi, ndwi2, sal,
        s2b, clay_pct, sand_pct, ph_soil, soc, lights
    ])


def build_soilgrids():
    valid = []
    def try_load(asset, bands, scale_factor=None, rename_map=None):
        try:
            img = ee.Image(asset); result = []
            for b in bands:
                band = img.select(b)
                if scale_factor: band = band.multiply(scale_factor)
                result.append(band.rename(rename_map.get(b, b) if rename_map else b))
            print(f"    ✅ {asset.split('/')[-1]}: {len(result)} bands"); return result
        except Exception as e:
            print(f"    ⚠️  {asset.split('/')[-1]}: {str(e)[:50]}"); return []

    valid += try_load("projects/soilgrids-isric/cec_mean",
        ['cec_0-5cm_mean','cec_5-15cm_mean','cec_15-30cm_mean','cec_30-60cm_mean'],
        rename_map={'cec_0-5cm_mean':'sg_cec_0','cec_5-15cm_mean':'sg_cec_5',
                    'cec_15-30cm_mean':'sg_cec_15','cec_30-60cm_mean':'sg_cec_30'})
    valid += try_load("projects/soilgrids-isric/bdod_mean",
        ['bdod_0-5cm_mean','bdod_5-15cm_mean','bdod_15-30cm_mean'],
        rename_map={'bdod_0-5cm_mean':'sg_bdod_0','bdod_5-15cm_mean':'sg_bdod_5',
                    'bdod_15-30cm_mean':'sg_bdod_15'})
    valid += try_load("projects/soilgrids-isric/phh2o_mean",
        ['phh2o_0-5cm_mean','phh2o_5-15cm_mean','phh2o_15-30cm_mean','phh2o_30-60cm_mean'],
        scale_factor=0.1,
        rename_map={'phh2o_0-5cm_mean':'sg_ph_0','phh2o_5-15cm_mean':'sg_ph_5',
                    'phh2o_15-30cm_mean':'sg_ph_15','phh2o_30-60cm_mean':'sg_ph_30'})
    valid += try_load("projects/soilgrids-isric/clay_mean",
        ['clay_0-5cm_mean','clay_5-15cm_mean','clay_15-30cm_mean'],
        scale_factor=0.1,
        rename_map={'clay_0-5cm_mean':'sg_clay_0','clay_5-15cm_mean':'sg_clay_5',
                    'clay_15-30cm_mean':'sg_clay_15'})
    valid += try_load("projects/soilgrids-isric/soc_mean",
        ['soc_0-5cm_mean','soc_5-15cm_mean','soc_15-30cm_mean'],
        rename_map={'soc_0-5cm_mean':'sg_soc_0','soc_5-15cm_mean':'sg_soc_5',
                    'soc_15-30cm_mean':'sg_soc_15'})
    valid += try_load("projects/soilgrids-isric/nitrogen_mean",
        ['nitrogen_0-5cm_mean','nitrogen_5-15cm_mean','nitrogen_15-30cm_mean'],
        rename_map={'nitrogen_0-5cm_mean':'sg_nitrogen_0','nitrogen_5-15cm_mean':'sg_nitrogen_5',
                    'nitrogen_15-30cm_mean':'sg_nitrogen_15'})
    valid += try_load("projects/soilgrids-isric/sand_mean",
        ['sand_0-5cm_mean','sand_5-15cm_mean'], scale_factor=0.1,
        rename_map={'sand_0-5cm_mean':'sg_sand_0','sand_5-15cm_mean':'sg_sand_5'})
    valid += try_load("projects/soilgrids-isric/silt_mean",
        ['silt_0-5cm_mean','silt_5-15cm_mean'], scale_factor=0.1,
        rename_map={'silt_0-5cm_mean':'sg_silt_0','silt_5-15cm_mean':'sg_silt_5'})

    if not valid: raise ValueError("No SoilGrids bands loaded")
    print(f"  ✅ SoilGrids {len(valid)} bands")
    return ee.Image.cat(valid)


def build_worldclim():
    wc  = ee.Image('WORLDCLIM/V1/BIO')
    bio = wc.select(['bio12','bio13','bio14','bio15','bio16','bio17','bio04','bio07']).rename([
          'wc_precip_annual','wc_precip_wet_month','wc_precip_dry_month',
          'wc_precip_seasonality','wc_precip_wet_quarter','wc_precip_dry_quarter',
          'wc_temp_seasonality','wc_temp_range'])
    wc_mon   = ee.ImageCollection('WORLDCLIM/V1/MONTHLY').select('prec')
    wc_std   = wc_mon.reduce(ee.Reducer.stdDev()).rename('wc_precip_monthly_std')
    wc_max   = wc_mon.reduce(ee.Reducer.max()).rename('wc_precip_monthly_max')
    wc_min   = wc_mon.reduce(ee.Reducer.min()).rename('wc_precip_monthly_min')
    wc_ratio = wc_mon.reduce(ee.Reducer.max()).divide(
               wc_mon.reduce(ee.Reducer.min()).add(1)).rename('wc_wet_dry_ratio')
    wc_ndry  = wc_mon.map(lambda i: i.lt(10).rename('d')).sum().rename('wc_n_dry_months')

    tc       = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE').filterDate(START, END).select(['soil','ro','pdsi','pet','aet','def'])
    tc_smean = tc.select('soil').mean().rename('tc_soil_mean')
    tc_ro    = tc.select('ro').mean().rename('tc_ro_mean')
    tc_pdsi  = tc.select('pdsi').mean().rename('tc_pdsi_mean')
    tc_pet   = tc.select('pet').mean().rename('tc_pet_mean')
    tc_aet   = tc.select('aet').mean().rename('tc_aet_mean')
    tc_def   = tc.select('def').mean().rename('tc_def_mean')
    tc_sstd  = tc.select('soil').reduce(ee.Reducer.stdDev()).rename('tc_soil_std')
    tc_pstd  = tc.select('pdsi').reduce(ee.Reducer.stdDev()).rename('tc_pdsi_std')
    tc_swet  = tc.filter(ee.Filter.calendarRange(10,3,'month')).select('soil').mean().rename('tc_soil_wet_season')
    tc_sdry  = tc.filter(ee.Filter.calendarRange(4,9,'month')).select('soil').mean().rename('tc_soil_dry_season')
    tc_samp  = tc_swet.subtract(tc_sdry).rename('tc_soil_amplitude')
    tc_sat   = tc.select('soil').map(lambda i: i.gt(150).rename('s')).sum().rename('tc_soil_sat_freq')
    tc_ratio = tc_aet.divide(tc_pet.add(0.1)).rename('tc_aet_pet_ratio')
    tc_dtot  = tc.select('def').sum().rename('tc_deficit_total')

    print("  ✅ WorldClim + TerraClimate 23 bands")
    return ee.Image.cat([
        bio, wc_std, wc_max, wc_min, wc_ratio, wc_ndry,
        tc_smean, tc_ro, tc_pdsi, tc_pet, tc_aet, tc_def,
        tc_sstd, tc_pstd, tc_swet, tc_sdry, tc_samp,
        tc_sat, tc_ratio, tc_dtot
    ])


# ── RUN ───────────────────────────────────────────────────────────────────────
if RUN_GEE:
    run('GEE',       build_gee,       'NewData_ee.csv',        batch_size=50,  scale=1000)
if RUN_SOILGRIDS:
    run('SOILGRIDS', build_soilgrids, 'NewData_sg.csv',        batch_size=100, scale=250)
if RUN_WORLDCLIM:
    run('WORLDCLIM', build_worldclim, 'NewData_worldclim.csv', batch_size=100, scale=1000)

print("\n✅ Notebook 1 done.")
