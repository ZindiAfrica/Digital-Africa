import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from datetime import timedelta
import os
import warnings

warnings.filterwarnings('ignore')

# ==========================================
# 1. CONFIGURATION
# ==========================================
# PWEZA CORE v47.1 Settings
TARGET_COUNTIES = ["kiambu", "kirinyaga", "mombasa", "nairobi", "uasin-gishu"]

# CASCADING LOGIC: Source -> Hub -> Spoke
PREDICTION_ORDER = ["uasin-gishu", "nairobi", "mombasa", "kiambu", "kirinyaga"]

# NEIGHBOR MAP
NEIGHBOR_MAP = {
    'uasin-gishu': [],            
    'nairobi': ['uasin-gishu'],   
    'mombasa': ['uasin-gishu'],   
    'kiambu': ['nairobi'],        
    'kirinyaga': ['nairobi']      
}

# HYPERPARAMETERS
BEST_PARAMS = {
    'learning_rate': 0.1,
    'max_depth': 3,
    'n_estimators': 500,
    'subsample': 0.85,
    'random_state': 42
}

FEATURE_COLS_BASE = [
    'sin_mon', 'cos_mon', 'lag_1', 'lag_2', 'lag_3', 'lag_4',
    'roll_4', 'roll_12', 'momentum',
    'yellow_spread', 'trad_spread', 'is_harvest_forced'
]

# STRICT FORECAST RANGE: Week 52 (2025) -> Week 2 (2026) = 3 Steps
FORECAST_STEPS = 3 

# ==========================================
# 2. DATA PIPELINE
# ==========================================
def process_data(files):
    print(">> [1/4] Loading Data...")
    dfs = []
    for name, path in files.items():
        if not os.path.exists(path):
            print(f"!! NOTE: File not found: {path}")
            continue
           
        try:
            df = pd.read_csv(path)
            df.columns = [c.lower().strip() for c in df.columns]
            if 'wholesale' in df.columns: df = df.rename(columns={'wholesale': 'price'})
           
            # Classification
            target_cols = [c for c in df.columns if 'commodity' in c or 'classification' in c]
            def classify(row):
                txt = " ".join([str(row[c]) for c in target_cols]).lower()
                if 'yellow' in txt: return 'yellow'
                if 'traditional' in txt: return 'traditional'
                if 'white' in txt: return 'white'
                return 'other'
           
            df['grain_type'] = df.apply(classify, axis=1)
            df = df[df['grain_type'] != 'other']
           
            # Weighting
            weight = 1.0
            if 'agribora' in name.lower(): weight = 100.0
            elif 'source' in df.columns and df['source'].astype(str).str.lower().eq('amis').any(): weight = 5.0
            df['weight'] = weight
           
            dfs.append(df)
           
        except Exception as e:
            print(f"!! Error reading {name}: {e}")

    # Merge
    full = pd.concat(dfs, ignore_index=True)
    full['price'] = pd.to_numeric(full['price'].astype(str).str.replace(r'[^\d.]', '', regex=True), errors='coerce')
    full['date'] = pd.to_datetime(full['date'], errors='coerce')
    full = full.dropna(subset=['price', 'date'])
   
    # Norms
    full['county'] = full['county'].astype(str).str.lower().str.strip()
    full['county'] = full['county'].replace({
        'uasin': 'uasin-gishu', 'uasin gishu': 'uasin-gishu',
        'trans nzoia': 'trans-nzoia', 'trans-nzioa': 'trans-nzoia'
    })
   
    full['week_date'] = full['date'].dt.to_period('W-MON').apply(lambda r: r.start_time)
   
    # Aggregation
    def w_mean(x):
        if x['weight'].sum() == 0: return x['price'].mean()
        return np.average(x['price'], weights=x['weight'])
   
    pivoted = full.groupby(['week_date', 'county', 'grain_type']).apply(w_mean).reset_index(name='price')
    pivoted = pivoted.pivot_table(index=['week_date', 'county'], columns='grain_type', values='price').reset_index()
   
    rename = {'white': 'price'}
    if 'yellow' in pivoted.columns: rename['yellow'] = 'price_yellow'
    if 'traditional' in pivoted.columns: rename['traditional'] = 'price_traditional'
    pivoted = pivoted.rename(columns=rename)
   
    for c in ['price', 'price_yellow', 'price_traditional']:
        if c not in pivoted.columns: pivoted[c] = np.nan

    # Feature Engineering
    df = pivoted.copy()
    df['price_yellow'] = df['price_yellow'].fillna(df['price'] * 0.8)
    df['price_traditional'] = df['price_traditional'].fillna(df['price'] * 1.1)
   
    # Cross-County Lags
    price_wide = df.pivot(index='week_date', columns='county', values='price')
    price_lags = price_wide.shift(1).add_suffix('_lag1')
    df = df.merge(price_lags, on='week_date', how='left')
   
    feat_dfs = []
    for county, sub in df.groupby('county'):
        sub = sub.set_index('week_date').sort_index()
        sub = sub.resample('W-MON').first()
        sub['county'] = county
        sub = sub.ffill()
       
        sub['month'] = sub.index.month
        sub['sin_mon'] = np.sin(2 * np.pi * sub['month']/12)
        sub['cos_mon'] = np.cos(2 * np.pi * sub['month']/12)
        sub['is_harvest_forced'] = sub['month'].apply(lambda m: 1 if m in [11, 12] else 0)
       
        sub['lag_1'] = sub['price'].shift(1)
        sub['lag_2'] = sub['price'].shift(2)
        sub['lag_3'] = sub['price'].shift(3)
        sub['lag_4'] = sub['price'].shift(4)
        sub['roll_4'] = sub['price'].shift(1).rolling(4).mean()
        sub['roll_12'] = sub['price'].shift(1).rolling(12).mean()
        sub['momentum'] = sub['lag_1'] - sub['lag_3']
        sub['yellow_spread'] = sub['price'] - sub['price_yellow']
        sub['trad_spread'] = sub['price_traditional'] - sub['price']
       
        feat_dfs.append(sub.reset_index())
       
    master = pd.concat(feat_dfs, ignore_index=True).dropna(subset=['lag_4', 'roll_12'])
    lag_cols = [c for c in master.columns if '_lag1' in c]
    master[lag_cols] = master[lag_cols].fillna(method='ffill').fillna(0)
   
    return master

# ==========================================
# 3. VALIDATION & BIAS OPTIMIZATION
# ==========================================
def validate_and_optimize(master_df):
    print("\n>> [2/4] Validating & Optimizing Bias (W46-W51)...")
   
    val_start = pd.to_datetime('2025-11-10')
    val_end = pd.to_datetime('2025-12-21')
   
    train_df = master_df[master_df['week_date'] < val_start]
    val_df = master_df[(master_df['week_date'] >= val_start) & (master_df['week_date'] <= val_end)]
   
    bias_map = {}
    validation_rows = []

    for county in TARGET_COUNTIES:
        # 1. Feature Selection
        neighbors = NEIGHBOR_MAP.get(county, [])
        neighbor_feats = [f"{n}_lag1" for n in neighbors]
        feats = FEATURE_COLS_BASE + neighbor_feats
        feats = [f for f in feats if f in master_df.columns]
       
        # 2. Training (Pre-W46)
        c_train = train_df[train_df['county'] == county]
        if len(c_train) < 10:
            bias_map[county] = 0.0
            continue
           
        model = GradientBoostingRegressor(**BEST_PARAMS)
        model.fit(c_train[feats], c_train['price'])
       
        # 3. Validation Prediction
        c_val = val_df[val_df['county'] == county]
        if c_val.empty:
            bias_map[county] = 0.0
            continue
           
        preds = model.predict(c_val[feats])
        actuals = c_val['price'].values
       
        # 4. Bias Grid Search
        best_bias = 0.0
        best_rmse = float('inf')
       
        for bias in np.arange(-2.0, 2.1, 0.05):
            rmse = np.sqrt(np.mean((preds + bias - actuals)**2))
            if rmse < best_rmse:
                best_rmse = rmse
                best_bias = bias
               
        bias_map[county] = best_bias
       
        # 5. Record Validation Rows for Display
        final_preds = preds + best_bias
        for idx, (i, row) in enumerate(c_val.iterrows()):
            validation_rows.append({
                'Week': row['week_date'].date(),
                'County': county,
                'GT': round(row['price'], 2),
                'Pred': round(final_preds[idx], 2),
                'Diff': round(final_preds[idx] - row['price'], 2)
            })

    # PRINT THE VALIDATION TABLE (The "Preview")
    print("\n=== VALIDATION REPORT (GT vs Optimized Neighbor Model) ===")
    val_disp = pd.DataFrame(validation_rows).sort_values(['County', 'Week'])
    print(val_disp.to_string(index=False))
    print("="*60)
       
    return bias_map

# ==========================================
# 4. PRODUCTION FORECAST (W52 - W02)
# ==========================================
def forecast_cascade(master_df, bias_map):
    print("\n>> [3/4] Retraining Models on Full History...")
   
    final_models = {}
    final_feats = {}
   
    for county in TARGET_COUNTIES:
        neighbors = NEIGHBOR_MAP.get(county, [])
        neighbor_feats = [f"{n}_lag1" for n in neighbors]
        feats = FEATURE_COLS_BASE + neighbor_feats
        feats = [f for f in feats if f in master_df.columns]
       
        c_df = master_df[master_df['county'] == county]
        model = GradientBoostingRegressor(**BEST_PARAMS)
        model.fit(c_df[feats], c_df['price'])
       
        final_models[county] = model
        final_feats[county] = feats

    print(">> [4/4] Generating Forecast: Week 52 (2025) -> Week 02 (2026)...")
   
    start_date = pd.to_datetime('2025-12-22') # Week 52 Start
    history_df = master_df.copy()
    forecast_rows = []
    sim_date = start_date
   
    for step in range(FORECAST_STEPS):
        m = sim_date.month
        step_predictions = {}
       
        # CASCADING PREDICTION
        for county in PREDICTION_ORDER:
            if county not in final_models: continue
           
            c_hist = history_df[history_df['county'] == county].sort_values('week_date')
            last = c_hist.iloc[-1]
           
            # Recalculate features
            l1, l2, l3, l4 = last['price'], last['lag_1'], last['lag_2'], last['lag_3']
            r4 = (l1+l2+l3+l4)/4.0
            r12 = (last['roll_12']*11 + l1)/12.0
            mom = l1 - l3
           
            row_dict = {
                'sin_mon': np.sin(2*np.pi*m/12),
                'cos_mon': np.cos(2*np.pi*m/12),
                'lag_1': l1, 'lag_2': l2, 'lag_3': l3, 'lag_4': l4,
                'roll_4': r4, 'roll_12': r12, 'momentum': mom,
                'yellow_spread': last['yellow_spread'],
                'trad_spread': last['trad_spread'],
                'is_harvest_forced': 1 if m in [11, 12] else 0
            }
           
            # Fetch Neighbor Lags (Dynamic)
            prev_date = sim_date - timedelta(weeks=1)
            neighbors = NEIGHBOR_MAP.get(county, [])
            for n in neighbors:
                n_col = f"{n}_lag1"
                n_price = history_df[(history_df['county'] == n) & (history_df['week_date'] == prev_date)]['price']
                row_dict[n_col] = n_price.values[0] if not n_price.empty else 0
           
            feats = final_feats[county]
            feat_vec = pd.DataFrame([row_dict])[feats]
           
            # Predict & Apply Bias
            raw_pred = final_models[county].predict(feat_vec)[0]
            final_pred = max(15.0, raw_pred + bias_map[county])
           
            step_predictions[county] = final_pred
           
            # ID Generation
            year, week, _ = sim_date.isocalendar()
            if "uasin" in county: c_fmt = "Uasin-Gishu"
            elif "trans" in county: c_fmt = "Trans-Nzoia"
            else: c_fmt = county.title()
           
            forecast_rows.append({
                'ID': f"{c_fmt}_Week_{week}",
                'Target_RMSE': round(final_pred, 2),
                'Target_MAE': round(final_pred, 2),
                'Date': sim_date.date(),
                'County': county
            })

        # HISTORY UPDATE
        for county, pred in step_predictions.items():
            last = history_df[history_df['county'] == county].iloc[-1]
            new_row = {
                'week_date': sim_date,
                'county': county,
                'price': pred,
                'weight': 1.0,
                'lag_1': last['price'],
                'lag_2': last['lag_1'],
                'lag_3': last['lag_2'],
                'lag_4': last['lag_3'],
                'roll_4': (last['price'] + last['lag_1'] + last['lag_2'] + last['lag_3'])/4.0,
                'roll_12': last['roll_12'],
                'yellow_spread': last['yellow_spread'],
                'trad_spread': last['trad_spread']
            }
            history_df = pd.concat([history_df, pd.DataFrame([new_row])], ignore_index=True)

        sim_date += timedelta(weeks=1)

    return pd.DataFrame(forecast_rows)

if __name__ == "__main__":
    FILES = {
        'kamis_raw': 'kamis_maize_prices_raw(1).csv',
        'agribora_hist': 'agriBORA_maize_prices(2).csv',
        'weeks_46_51': 'agriBORA_maize_prices_weeks_46_to_51.csv'
    }
   
    # 1. Pipeline
    master = process_data(FILES)
   
    # 2. Optimize & Display Preview
    bias_map = validate_and_optimize(master)
   
    # 3. Final Forecast
    sub_df = forecast_cascade(master, bias_map)
   
    # 4. Save
    sub_df[['ID', 'Target_RMSE', 'Target_MAE']].to_csv('submission.csv', index=False)
    print("\n✅ GENERATION COMPLETE: 'submission.csv'")
    print(f"   Generated {len(sub_df)} rows (Weeks 52, 1, 2).")